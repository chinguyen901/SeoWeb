# db/models.py
"""
Các model Python thuần (dataclass) để map với Big DB.
"""

from dataclasses import dataclass
from typing import Any, Dict, Optional


# ========== FLOW ==========

@dataclass
class FlowStep:
    """
    Một dòng trong sheet Flow sau khi nhập vào DB.

    - var0..var6 đều được lưu dạng TEXT (thường là JSON array string).
    - session_id cho phép cùng DB chứa nhiều lần chạy khác nhau.
    """
    id: Optional[int]
    session_id: str
    step: int
    function: str
    name: str
    output_col: str
    var0: str
    var1: str = ""
    var2: str = ""
    var3: str = ""
    var4: str = ""
    var5: str = ""
    var6: str = ""


# ========== DASHBOARD / JOB ==========

@dataclass
class DashboardRow:
    """
    Một dòng trong Dashboard.

    - row_index: index của dòng trong Excel (1-based hay 0-based tuỳ bạn chọn).
    - status: start / pending / done
    - data: dict chứa toàn bộ các cột dữ liệu khác (url, content, ...).
    """
    id: Optional[int]
    session_id: str
    row_index: int
    status: str
    data: Dict[str, Any]


@dataclass
class Job:
    """
    Job là "phiên bản runtime" của DashboardRow (thường giống 1-1).
    Bạn có thể thêm field tạm (runtime-only) nếu cần.
    """
    id: int
    session_id: str
    row_index: int
    status: str
    data: Dict[str, Any]


# ========== LOG ==========

@dataclass
class LogRecord:
    """
    Dòng log trong DB.
    """
    id: Optional[int]
    session_id: str
    job_id: Optional[int]
    level: str
    message: str
    created_at: str  # ISO 8601 string
