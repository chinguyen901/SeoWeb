# backend/flow_engine/step_executor.py
# =========================================
# Main worker logic cho từng JOB
# =========================================

import os
import json
import sqlite3
from typing import List, Dict, Any, Callable

from concurrent.futures import ThreadPoolExecutor

from backend.flow_engine.syntax_replace import syntax_replace_step
from backend.flow_engine.var_rules import validate_vars

from backend.actions.format_image import format_image
from backend.actions.search_image import search_image
from backend.actions.crawler import action_crawler
from backend.actions.extract_object import extract_object
from backend.actions.prompt_text import prompt_text
from backend.actions.prompt_image import prompt_image
from backend.actions.cloudinary import cloudinary_upload
from backend.actions.wordpress import wordpress

class ThreadLogBuffer:
    def __init__(self):
        self.lines: List[str] = []

    def add(self, text: str):
        self.lines.append(text)

    def flush(self, log_callback: Callable[[str], None]):
        for line in self.lines:
            log_callback(line)

# -----------------------------------------------------------
# SAVE OUTPUT by ROW-INDEX (NOT ID)
# -----------------------------------------------------------
def update_dashboard_sql(db_path: str, row_index: int, col: str, value: Any):
    """Lưu vào Dashboard.<col> theo số dòng (row_index)."""
    try:
        conn = sqlite3.connect(db_path)
        cur = conn.cursor()

        cur.execute("PRAGMA table_info(Dashboard)")
        columns = [c[1] for c in cur.fetchall()]
        if col not in columns:
            raise Exception(f"Column '{col}' does not exist in Dashboard")

        json_str = json.dumps(value, ensure_ascii=False)

        cur.execute(
            f"""
            UPDATE Dashboard 
            SET {col} = ?
            WHERE rowid = (
                SELECT rowid FROM Dashboard ORDER BY rowid LIMIT 1 OFFSET ?
            )
            """,
            (json_str, row_index - 1),
        )

        conn.commit()
        conn.close()
        return True

    except Exception as e:
        print("❌ SQL UPDATE ERROR:", e)
        return False


# -----------------------------------------------------------
# HANDLE OUTPUT → Dashboard
# -----------------------------------------------------------
def handle_output_mapping(step, job, output, db_path: str, log_callback):
    output_map = step.get("Output")

    if not output_map:
        return

    if not (output_map.startswith("~~") and output_map.endswith("~~")):
        return

    try:
        inner = output_map.replace("~~", "")
        col, table = inner.split(".")

        if table.lower() != "dashboard":
            return

        row_index = job.get("_row")
        ok = update_dashboard_sql(db_path, row_index, col, output)

        if ok:
            log_callback(f"       💾 Saved output → Dashboard.{col}")
        else:
            log_callback(f"       ❌ FAILED Save to Dashboard.{col}")

    except Exception as e:
        log_callback(f"       ❌ Output map ERROR: {e}")


# -----------------------------------------------------------
# EXECUTE 1 STEP
# -----------------------------------------------------------
def execute_step(step: Dict[str, Any], job: Dict[str, Any], db_path: str, log_callback):
    action = step.get("Action")
    step_num = step.get("Step")
    log_callback(f"    ▶ Thực thi Step {step_num}: action={action}")

    # =======================================================
    # ACTION: CRAWLER
    # =======================================================
    if action == "crawler":
        var0 = step.get("Var0")
        var1 = step.get("Var1")
        var2 = step.get("Var2")

        errors = validate_vars(step, log_callback)
        if errors:
            log_callback("❌ VAR VALIDATION FAILED:")
            for e in errors:
                log_callback(f"      • {e}")

            output = {"success": False, "errors": errors}

            return output

        log_callback(f"       • [ACTION=crawler] var0={var0}, var1={var1}, var2={var2}")

        output = action_crawler(var0, var1, var2, log_callback)
        
        log_callback(f"       ✔ Output crawler: {output}")


        handle_output_mapping(step, job, output, db_path, log_callback)
        return output

    # =======================================================
    # ACTION: EXTRACT_OBJECT
    # =======================================================
    if action == "extract_object":
        var0 = step.get("Var0")
        var1 = step.get("Var1")
        var2 = step.get("Var2")
        var3 = step.get("Var3")
        var4 = step.get("Var4")

        errors = validate_vars(step, log_callback)
        if errors:
            log_callback("❌ VAR VALIDATION FAILED (extract_object):")
            for e in errors:
                log_callback(f"      • {e}")

            output = {"success": False, "errors": errors}

        log_callback(f"       • [ACTION=extract_object] var0={var0}, var1={var1}, var2={var2}, var3={var3}, var4={var4}")

        output = extract_object(
            var0=var0,
            var1=var1,
            var2=var2,
            var3=var3,
            var4=var4,
            log_callback=log_callback,
        )

        log_callback(f"       ✔ Output extract_object: {output}")

        handle_output_mapping(step, job, output, db_path, log_callback)
        return output
    
    # =======================================================
    # ACTION: PROMPT_TEXT
    # =======================================================
    if action == "prompt_text":
        log_callback("       • [ACTION=prompt_text] Preparing input...")

        var0 = step.get("Var0")
        var1 = step.get("Var1")
        var2 = step.get("Var2")
        var3 = step.get("Var3")
        var4 = step.get("Var4")

        log_callback(f"       • [ACTION=prompt_text] Running with var0={var0}")

        output = prompt_text(
            var0=var0,
            var1=var1,
            var2=var2,
            var3=var3,
            var4=var4,
            log_callback=log_callback,
        )

        log_callback(f"       ✔ Output prompt_text: {output}")

        handle_output_mapping(step, job, output, db_path, log_callback)
        return output

    # =======================================================
    # ACTION: PROMPT_iMAGE
    # =======================================================
    if action == "prompt_image":
        log_callback("       • [ACTION=prompt_image] Preparing input...")

        var0 = step.get("Var0")
        var1 = step.get("Var1")
        var2 = step.get("Var2")
        var3 = step.get("Var3")
        var4 = step.get("Var4")

        log_callback(f"       • [ACTION=prompt_image] Running with var0={var0}")

        output = prompt_image(
            var0=var0,
            var1=var1,
            var2=var2,
            var3=var3,
            var4=var4,
            log_callback=log_callback,
        )

        log_callback(f"       ✔ Output prompt_image: {output}")

        handle_output_mapping(step, job, output, db_path, log_callback)
        return output

    # =======================================================
    # ACTION: PROMPT_iMAGE
    # =======================================================
    if action == "search_image":
        log_callback("       • [ACTION=search_image] Preparing input...")

        var0 = step.get("Var0")
        var1 = step.get("Var1")
        var2 = step.get("Var2")
        var3 = step.get("Var3")
        var4 = step.get("Var4")

        log_callback(f"       • [ACTION=search_image] Running with var0={var0}")

        output = search_image(
            var0=var0,
            var1=var1,
            var2=var2,
            var3=var3,
            var4=var4,
            log_callback=log_callback,
        )

        log_callback(f"       ✔ Output search_image: {output}")

        handle_output_mapping(step, job, output, db_path, log_callback)
        return output

    # =======================================================
    # ACTION: FORMAT_IMAGE
    # =======================================================
    if action == "format_image":
        log_callback("       • [ACTION=format_image] Preparing input...")

        var0 = step.get("Var0")
        var1 = step.get("Var1")
        var2 = step.get("Var2")
        var3 = step.get("Var3")
        var4 = step.get("Var4")
        var5 = step.get("Var5")
        var6 = step.get("Var6")

        log_callback(f"       • [ACTION=format_image] Running with var0={var0}")

        output = format_image(
            var0=var0,
            var1=var1,
            var2=var2,
            var3=var3,
            var4=var4,
            var5=var5,
            var6=var6,
            log_callback=log_callback,
        )

        log_callback(f"       ✔ Output format_image: {output}")

        handle_output_mapping(step, job, output, db_path, log_callback)
        return output

    # =======================================================
    # ACTION: CLOUDINARY
    # =======================================================
    if action == "cloudinary":
        log_callback("       • [ACTION=cloudinary] Preparing input...")

        var0 = step.get("Var0")
        var1 = step.get("Var1")
        var2 = step.get("Var2")
        var3 = step.get("Var3")
        var4 = step.get("Var4")

        log_callback(f"       • [ACTION=cloudinary] Running with var0={var0}")

        output = cloudinary_upload(
            var0=var0,
            var1=var1,
            var2=var2,
            var3=var3,
            var4=var4,
            log_callback=log_callback,
        )

        log_callback(f"       ✔ Output cloudinary: {output}")

        handle_output_mapping(step, job, output, db_path, log_callback)
        return output
    
        # =======================================================
    
    # =======================================================
    # ACTION: WORDPRESS
    # =======================================================
    if action == "wordpress":
        log_callback("       • [ACTION=wordpress] Preparing input...")

        var0 = step.get("Var0")
        var1 = step.get("Var1")
        var2 = step.get("Var2")
        var3 = step.get("Var3")
        var4 = step.get("Var4")

        log_callback(f"       • [ACTION=wordpress] Running with var0={var0}")

        output = wordpress(
            var0=var0,
            var1=var1,
            var2=var2,
            var3=var3,
            var4=var4,
            log_callback=log_callback,
        )

        log_callback(f"       ✔ Output wordpress: {output}")

        handle_output_mapping(step, job, output, db_path, log_callback)
        return output
    # =======================================================
    log_callback(f"       ⚠ Action '{action}' chưa được định nghĩa!")
    return None


# -----------------------------------------------------------
# RUN SINGLE JOB
# -----------------------------------------------------------
def run_single_job(job, flow_steps, db_path: str, log_callback, stop_event):
    row_index = job.get("_row")

    buffer = ThreadLogBuffer()

    def log(text: str):
        buffer.add(text)

    log(f"🧵 Bắt đầu job ROW={row_index}")

    job_flow = [dict(s) for s in flow_steps]
    job_flow.sort(key=lambda x: x.get("step", x.get("Step", 0)))

    for step in job_flow:
        if stop_event.is_set():
            log(f"⛔ Job ROW={row_index} STOP.")
            buffer.flush(log_callback)
            return

        step_ready = syntax_replace_step(step, job)

        log(f"🔄 INPUT STEP {step_ready.get('step', step_ready.get('Step'))} SAU KHI REPLACE:")
        for k, v in step_ready.items():
            log(f"     • {k}: {v}")

        execute_step(step_ready, job, db_path, log)

    log(f"✅ Job ROW={row_index} hoàn thành.")
    buffer.flush(log_callback)
