# infrastructure/excel_io.py
"""
Các hàm tiện ích đọc file Excel (Flow, Dashboard) bằng pandas.
Không phụ thuộc vào SQLite hay BigData – chỉ xử lý Excel "thô".
"""

from pathlib import Path
from typing import Dict, Optional, Tuple

import pandas as pd


def read_excel_all_sheets(excel_path: str | Path) -> Dict[str, pd.DataFrame]:
    """
    Đọc toàn bộ sheet trong Excel và trả về dict:
    {
        "Flow": DataFrame,
        "Dashboard": DataFrame,
        ...
    }
    """
    excel_path = Path(excel_path)

    if not excel_path.exists():
        raise FileNotFoundError(f"Không tìm thấy file Excel: {excel_path}")

    xls = pd.ExcelFile(excel_path)
    result: Dict[str, pd.DataFrame] = {}

    for sheet_name in xls.sheet_names:
        df = pd.read_excel(excel_path, sheet_name=sheet_name)
        result[sheet_name] = df

    return result


def read_flow_and_dashboard(
    excel_path: str | Path,
    flow_sheet_name: str = "Flow",
    dashboard_sheet_name: str = "Dashboard",
) -> Tuple[Optional[pd.DataFrame], Optional[pd.DataFrame]]:
    """
    Đọc riêng 2 sheet Flow & Dashboard nếu tồn tại.
    Trả về: (flow_df, dashboard_df) – có thể là None nếu sheet không có.
    """
    excel_path = Path(excel_path)

    if not excel_path.exists():
        raise FileNotFoundError(f"Không tìm thấy file Excel: {excel_path}")

    xls = pd.ExcelFile(excel_path)

    flow_df: Optional[pd.DataFrame] = None
    dashboard_df: Optional[pd.DataFrame] = None

    for sheet in xls.sheet_names:
        name_lower = sheet.strip().lower()

        if name_lower == flow_sheet_name.lower():
            flow_df = pd.read_excel(excel_path, sheet_name=sheet)

        elif name_lower == dashboard_sheet_name.lower():
            dashboard_df = pd.read_excel(excel_path, sheet_name=sheet)

    return flow_df, dashboard_df
