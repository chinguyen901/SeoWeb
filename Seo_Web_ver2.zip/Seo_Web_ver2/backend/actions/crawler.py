# from __future__ import annotations

# import asyncio
# import re
# from bs4 import BeautifulSoup
# from typing import Any, List, Optional, Callable, Dict

# from crawl4ai import AsyncWebCrawler, CrawlerRunConfig  # pip install crawl4ai
# from crawl4ai.content_filter_strategy import PruningContentFilter
# from crawl4ai.markdown_generation_strategy import DefaultMarkdownGenerator

# LogCallback = Callable[[str], None]


# class CrawlerAction:
#     """
#     ACTION: crawler

#     Quy ước:
#     - var0:
#         1 → SINGLE  (var1 là 1 url hoặc list 1 phần tử)
#         0 → MULTI   (var1 là list nhiều url)
#     - var1:
#         - string: 1 URL (có hoặc không có http/https)
#         - list[str]: nhiều URL

#     - var2: loại dữ liệu muốn lấy từ CrawlResult cho mỗi URL
#         Hỗ trợ:
#         - "markdown"         → markdown đã lọc rác (ưu tiên fit_markdown, fallback raw_markdown)
#         - "cleaned_html"     → cleaned_html (fallback html)
#         - "extract_content"  → result.extracted_content
#         - "metadata"         → result.metadata (dict: title/lang/meta...)

#       Có thể truyền:
#         - string: "markdown" hoặc "markdown,metadata"
#         - list[str]: ["markdown","metadata"]

#     - Kết quả luôn là list, mỗi phần tử ứng với 1 URL:
#         [
#           {
#             "url": "...",
#             "markdown": "...",
#             "cleaned_html": "...",
#             "extract_content": "...",
#             "metadata": {...}
#           },
#           ...
#         ]
#       (chỉ chứa những key được yêu cầu trong var2)
#     """

#     name = "crawler"

#     def __init__(self):
#         ...

#     # ----------------------------------------------------
#     # Hàm chính cho action (backend gọi qua action_crawler)
#     # ----------------------------------------------------
#     def run(
#         self,
#         *,
#         var0: Any = None,
#         var1: Any = None,
#         var2: Any = None,
#         log_callback: Optional[LogCallback] = None,
#     ) -> List[dict]:
#         if log_callback is None:
#             log_callback = print

#         mode = self._normalize_var0(var0)
#         urls = self._normalize_var1_to_urls(var1, mode, log_callback)
#         fields = self._normalize_var2_to_fields(var2, log_callback)

#         if not urls:
#             log_callback("[crawler] Không có URL hợp lệ để crawl.")
#             return []

#         log_callback(
#             f"[crawler] Bắt đầu crawl {len(urls)} URL với fields={fields}..."
#         )

#         # Chạy async crawler trong môi trường sync
#         try:
#             results = asyncio.run(
#                 self._crawl_many(urls, fields, log_callback)
#             )
#         except RuntimeError:
#             # Phòng trường hợp đang trong event loop khác (ví dụ IDE, notebook)
#             loop = asyncio.new_event_loop()
#             try:
#                 asyncio.set_event_loop(loop)
#                 results = loop.run_until_complete(
#                     self._crawl_many(urls, fields, log_callback)
#                 )
#             finally:
#                 loop.close()

#         log_callback(f"[crawler] Hoàn thành crawl {len(results)} URL.")
#         return results

#     # ----------------------------------------------------
#     # Helpers: Var0 / Var1 / Var2
#     # ----------------------------------------------------
#     def _normalize_var0(self, var0: Any) -> int:
#         """
#         Chuẩn hoá Var0 về int 0/1.
#         Mặc định = 1 (single) nếu parse không được.
#         """
#         try:
#             if isinstance(var0, float) and var0.is_integer():
#                 var0 = int(var0)
#             v = int(str(var0).strip())
#             return 1 if v != 0 else 0
#         except Exception:
#             return 1  # default SINGLE

#     def _fix_url_scheme(self, url: str, log_callback: LogCallback) -> Optional[str]:
#         """
#         Đảm bảo URL có scheme phù hợp với crawl4ai.
#         - Nếu thiếu http/https/file/raw → tự thêm https://
#         - Nếu trống → trả về None
#         """
#         if not url:
#             return None

#         url = url.strip()
#         if not url:
#             return None

#         prefixes = ("http://", "https://", "file://", "raw:")
#         if url.startswith(prefixes):
#             return url

#         # Tự động thêm https:// nếu không có
#         fixed = "https://" + url
#         log_callback(
#             f"[crawler] URL '{url}' thiếu scheme, tự đổi thành '{fixed}'"
#         )
#         return fixed

#     def _normalize_var1_to_urls(
#         self,
#         var1: Any,
#         mode: int,
#         log_callback: LogCallback,
#     ) -> List[str]:
#         """
#         Biến var1 thành list URL:
#         - SINGLE:
#             var1 = "gi8dangnhap.com" → ["https://gi8dangnhap.com"]
#             var1 = ["abc.com"]        → ["https://abc.com"]
#         - MULTI:
#             var1 = ["u1","u2",...]    → list các URL đã fix scheme
#         """
#         urls: List[str] = []

#         if isinstance(var1, str):
#             fixed = self._fix_url_scheme(var1, log_callback)
#             if fixed:
#                 urls = [fixed]

#         elif isinstance(var1, list):
#             for item in var1:
#                 if not isinstance(item, str):
#                     continue
#                 fixed = self._fix_url_scheme(item, log_callback)
#                 if fixed:
#                     urls.append(fixed)
#         else:
#             log_callback(f"[crawler] Var1 nhận kiểu không hỗ trợ: {type(var1)}")

#         # Nếu SINGLE nhưng list >1, log cảnh báo nhưng vẫn xử lý hết
#         if mode == 1 and len(urls) > 1:
#             log_callback(
#                 f"[crawler] Var0=1 (SINGLE) nhưng Var1 có {len(urls)} URL, vẫn crawl tất cả."
#             )

#         return urls

#     def _normalize_var2_to_fields(
#         self,
#         var2: Any,
#         log_callback: LogCallback,
#     ) -> List[str]:
#         """
#         Chuẩn hoá Var2 thành list field hợp lệ.
#         Hỗ trợ alias:
#         - "extract_content" hoặc "extracted_content" → extract_content
#         """
#         default_fields = ["markdown"]

#         if var2 is None:
#             return default_fields

#         raw_items: List[str] = []

#         if isinstance(var2, str):
#             raw_items = [p.strip() for p in var2.split(",") if p.strip()]
#         elif isinstance(var2, list):
#             for item in var2:
#                 if isinstance(item, str):
#                     parts = [p.strip() for p in item.split(",") if p.strip()]
#                     raw_items.extend(parts)
#         else:
#             log_callback(f"[crawler] Var2 nhận kiểu không hỗ trợ: {type(var2)}")
#             return default_fields

#         # Chuẩn hoá & lọc hợp lệ
#         normalized: List[str] = []
#         for f in raw_items:
#             f_lower = f.lower()
#             if f_lower in {"markdown", "cleaned_html", "metadata"}:
#                 normalized.append(f_lower)
#             elif f_lower in {"extract_content", "extracted_content"}:
#                 normalized.append("extract_content")
#             else:
#                 log_callback(
#                     f"[crawler] Var2 field không hợp lệ, bỏ qua: '{f}'"
#                 )

#         if not normalized:
#             log_callback(
#                 "[crawler] Var2 không có field hợp lệ, dùng mặc định: ['markdown']"
#             )
#             return default_fields

#         # Loại trùng
#         return list(dict.fromkeys(normalized))

#     # ----------------------------------------------------
#     # Async crawler thực sự
#     # ----------------------------------------------------
#     async def _crawl_many(
#         self,
#         urls: List[str],
#         fields: List[str],
#         log_callback: LogCallback,
#     ) -> List[dict]:
#         """
#         Chạy AsyncWebCrawler cho nhiều URL.
#         Trả về list dict, mỗi dict chỉ chứa những key được yêu cầu trong fields.
#         """

#         results: List[dict] = []

#         # Cấu hình Markdown Generator với PruningContentFilter để lọc rác
#         pruning_filter = PruningContentFilter(
#             # bạn có thể tinh chỉnh các tham số này nếu muốn
#             threshold=0.45,
#             threshold_type="dynamic",
#             min_word_threshold=5,
#         )
#         md_generator = DefaultMarkdownGenerator(
#             content_filter=pruning_filter
#         )
#         run_config = CrawlerRunConfig(
#             markdown_generator=md_generator
#         )

#         async with AsyncWebCrawler() as crawler:
#             for idx, url in enumerate(urls, start=1):
#                 try:
#                     log_callback(f"[crawler] ({idx}/{len(urls)}) Crawling: {url}")
#                     result = await crawler.arun(url=url, config=run_config)

#                     # Tạo output cho từng URL
#                     item: Dict[str, Any] = {"url": url}
#                     html = result.html or ""
#                     soup = BeautifulSoup(html, "lxml")
#                     # --- markdown (ưu tiên fit_markdown, fallback raw_markdown/string) ---
#                     if "markdown" in fields:
#                         md_value = ""
#                         md_obj = getattr(result, "markdown", None)

#                         if isinstance(md_obj, str):
#                             # Một số version có thể trả trực tiếp string
#                             md_value = md_obj
#                         elif md_obj is not None:
#                             fit_md = getattr(md_obj, "fit_markdown", None)
#                             raw_md = getattr(md_obj, "raw_markdown", None)
#                             md_value = fit_md or raw_md or ""
#                         item["markdown"] = md_value

#                     # --- cleaned_html ---
#                     if "cleaned_html" in fields:
#                         cleaned = getattr(result, "cleaned_html", None)
#                         if not cleaned:
#                             cleaned = getattr(result, "html", "") or ""
#                         item["cleaned_html"] = cleaned

#                     # --- extract_content (map từ result.extracted_content) ---
#                     if "extract_content" in fields:
#                         text = soup.get_text(" ", strip=True)
#                         text = re.sub(r"\s+", " ", text)
#                         content = text[:10000]
#                         # extracted = getattr(result, "extracted_content", None) or ""
#                         item["extract_content"] = content

#                     # --- metadata ---
#                     if "metadata" in fields:
#                         meta = getattr(result, "metadata", None) or {}
#                         item["metadata"] = meta

#                     log_callback(f"[crawler] ✅ Đã crawl xong: {url}")
#                     results.append(item)

#                 except Exception as e:
#                     log_callback(f"[crawler] ❌ Lỗi crawl {url}: {e}")
#                     err_item: Dict[str, Any] = {
#                         "url": url,
#                         "error": str(e),
#                     }
#                     # Đảm bảo có đủ key trống nếu người dùng yêu cầu
#                     if "markdown" in fields:
#                         err_item.setdefault("markdown", "")
#                     if "cleaned_html" in fields:
#                         err_item.setdefault("cleaned_html", "")
#                     if "extract_content" in fields:
#                         err_item.setdefault("extract_content", "")
#                     if "metadata" in fields:
#                         err_item.setdefault("metadata", {})
#                     results.append(err_item)

#         return results


# # --------------------------------------------------------
# # Adapter: cho backend dùng cho đơn giản
# # --------------------------------------------------------
# def action_crawler(
#     var0: Any,
#     var1: Any,
#     var2: Any = None,
#     log_callback: Optional[LogCallback] = None,
# ) -> List[dict]:
#     """
#     Cho backend gọi như cũ:
#         output = action_crawler(var0, var1, var2, log_callback)

#     - var2: field(s) muốn lấy, ví dụ:
#         "markdown"
#         "markdown,metadata"
#         ["markdown","cleaned_html","metadata"]
#     """
#     action = CrawlerAction()
#     return action.run(
#         var0=var0,
#         var1=var1,
#         var2=var2,
#         log_callback=log_callback,
#     )
# actions/crawler.py
from __future__ import annotations

import re
import asyncio
from bs4 import BeautifulSoup
from typing import Any, List, Optional, Callable, Dict

from crawl4ai import (
    AsyncWebCrawler,
    CrawlerRunConfig,
    BrowserConfig,
)
from crawl4ai.content_filter_strategy import PruningContentFilter
from crawl4ai.markdown_generation_strategy import DefaultMarkdownGenerator


LogCallback = Callable[[str], None]


class CrawlerAction:
    """
    ACTION: crawler

    Quy ước:
    - var0:
        1 → SINGLE  (var1 là 1 url hoặc list 1 phần tử)
        0 → MULTI   (var1 là list nhiều url)

    - var1:
        - string: 1 URL (có hoặc không có http/https)
        - list[str]: nhiều URL

    - var2: loại dữ liệu muốn lấy từ CrawlResult cho mỗi URL
        Hỗ trợ:
        - "markdown"         → markdown đã lọc rác (ưu tiên fit_markdown, fallback raw_markdown)
        - "cleaned_html"     → cleaned_html (fallback html)
        - "extract_content"  → result.extracted_content
        - "metadata"         → result.metadata (dict: title/lang/meta...)

      Có thể truyền:
        - string: "markdown" hoặc "markdown,metadata"
        - list[str]: ["markdown","metadata"]

    - Kết quả luôn là list, mỗi phần tử ứng với 1 URL:
        [
          {
            "url": "...",
            "markdown": "...",
            "cleaned_html": "...",
            "extract_content": "...",
            "metadata": {...}
          },
          ...
        ]
      (chỉ chứa những key được yêu cầu trong var2)
    """

    name = "crawler"

    def __init__(self):
        ...

    # ----------------------------------------------------
    # Hàm chính cho action (backend gọi qua action_crawler)
    # ----------------------------------------------------
    def run(
        self,
        *,
        var0: Any = None,
        var1: Any = None,
        var2: Any = None,
        log_callback: Optional[LogCallback] = None,
    ) -> List[dict]:
        if log_callback is None:
            log_callback = print

        mode = self._normalize_var0(var0)
        urls = self._normalize_var1_to_urls(var1, mode, log_callback)
        fields = self._normalize_var2_to_fields(var2, log_callback)

        if not urls:
            log_callback("[crawler] Không có URL hợp lệ để crawl.")
            return []

        log_callback(
            f"[crawler] Bắt đầu crawl {len(urls)} URL với fields={fields}..."
        )

        # Chạy async crawler trong môi trường sync
        try:
            results = asyncio.run(
                self._crawl_many(urls, fields, log_callback)
            )
        except RuntimeError:
            # Phòng trường hợp đang trong event loop khác (ví dụ IDE, notebook)
            loop = asyncio.new_event_loop()
            try:
                asyncio.set_event_loop(loop)
                results = loop.run_until_complete(
                    self._crawl_many(urls, fields, log_callback)
                )
            finally:
                loop.close()

        log_callback(f"[crawler] Hoàn thành crawl {len(results)} URL.")
        return results

    # ----------------------------------------------------
    # Helpers: Var0 / Var1 / Var2
    # ----------------------------------------------------
    def _normalize_var0(self, var0: Any) -> int:
        """
        Chuẩn hoá Var0 về int 0/1.
        Mặc định = 1 (single) nếu parse không được.
        """
        try:
            if isinstance(var0, float) and var0.is_integer():
                var0 = int(var0)
            v = int(str(var0).strip())
            return 1 if v != 0 else 0
        except Exception:
            return 1  # default SINGLE

    def _fix_url_scheme(self, url: str, log_callback: LogCallback) -> Optional[str]:
        """
        Đảm bảo URL có scheme phù hợp với crawl4ai.
        - Nếu thiếu http/https/file/raw → tự thêm https://
        - Nếu trống → trả về None
        """
        if not url:
            return None

        url = url.strip()
        if not url:
            return None

        prefixes = ("http://", "https://", "file://", "raw:")
        if url.startswith(prefixes):
            return url

        # Tự động thêm https:// nếu không có
        fixed = "https://" + url
        log_callback(
            f"[crawler] URL '{url}' thiếu scheme, tự đổi thành '{fixed}'"
        )
        return fixed

    def _normalize_var1_to_urls(
        self,
        var1: Any,
        mode: int,
        log_callback: LogCallback,
    ) -> List[str]:
        """
        Biến var1 thành list URL:
        - SINGLE:
            var1 = "gi8dangnhap.com" → ["https://gi8dangnhap.com"]
            var1 = ["abc.com"]        → ["https://abc.com"]
        - MULTI:
            var1 = ["u1","u2",...]    → list các URL đã fix scheme
        """
        urls: List[str] = []

        if isinstance(var1, str):
            fixed = self._fix_url_scheme(var1, log_callback)
            if fixed:
                urls = [fixed]

        elif isinstance(var1, list):
            for item in var1:
                if not isinstance(item, str):
                    continue
                fixed = self._fix_url_scheme(item, log_callback)
                if fixed:
                    urls.append(fixed)
        else:
            log_callback(f"[crawler] Var1 nhận kiểu không hỗ trợ: {type(var1)}")

        # Nếu SINGLE nhưng list >1, log cảnh báo nhưng vẫn xử lý hết
        if mode == 1 and len(urls) > 1:
            log_callback(
                f"[crawler] Var0=1 (SINGLE) nhưng Var1 có {len(urls)} URL, vẫn crawl tất cả."
            )

        return urls

    def _normalize_var2_to_fields(
        self,
        var2: Any,
        log_callback: LogCallback,
    ) -> List[str]:
        """
        Chuẩn hoá Var2 thành list field hợp lệ.
        Hỗ trợ alias:
        - "extract_content" hoặc "extracted_content" → extract_content
        """
        default_fields = ["markdown"]

        if var2 is None:
            return default_fields

        raw_items: List[str] = []

        if isinstance(var2, str):
            raw_items = [p.strip() for p in var2.split(",") if p.strip()]
        elif isinstance(var2, list):
            for item in var2:
                if isinstance(item, str):
                    parts = [p.strip() for p in item.split(",") if p.strip()]
                    raw_items.extend(parts)
        else:
            log_callback(f"[crawler] Var2 nhận kiểu không hỗ trợ: {type(var2)}")
            return default_fields

        # Chuẩn hoá & lọc hợp lệ
        normalized: List[str] = []
        for f in raw_items:
            f_lower = f.lower()
            if f_lower in {"markdown", "cleaned_html", "metadata"}:
                normalized.append(f_lower)
            elif f_lower in {"extract_content", "extracted_content"}:
                normalized.append("extract_content")
            else:
                log_callback(
                    f"[crawler] Var2 field không hợp lệ, bỏ qua: '{f}'"
                )

        if not normalized:
            log_callback(
                "[crawler] Var2 không có field hợp lệ, dùng mặc định: ['markdown']"
            )
            return default_fields

        # Loại trùng
        return list(dict.fromkeys(normalized))

    # ----------------------------------------------------
    # BrowserConfig: cấu hình "khó tính", giống người thật
    # ----------------------------------------------------
    # def _create_browser_config(self, log_callback: LogCallback) -> BrowserConfig:
    #     """
    #     Tạo BrowserConfig hơi "khó tính":
    #     - headless=False  → giống người thật, khó bị detect hơn
    #     - enable_stealth=True → bật stealth mode
    #     - headers.User-Agent  → fake Chrome phổ biến
    #     """
    #     ua = (
    #         "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    #         "AppleWebKit/537.36 (KHTML, like Gecko) "
    #         "Chrome/123.0.0.0 Safari/537.36"
    #     )

    #     cfg = BrowserConfig(
    #         headless=False,           # tránh bị detect headless
    #         enable_stealth=True,      # bật stealth mode
    #         verbose=False,
    #         headers={"User-Agent": ua}
    #     )

    #     log_callback("[crawler] Đã khởi tạo BrowserConfig với stealth + UA giả lập Chrome.")
    #     return cfg
    
    def _create_browser_config(self, log_callback: LogCallback) -> BrowserConfig:
        """
        BrowserConfig chạy NGẦM (headless=True) nhưng được tối ưu để giảm detect:

        - headless=True  → không hiển thị cửa sổ
        - enable_stealth=True → tránh bị phát hiện tự động hóa
        - Fake User-Agent phổ biến
        - Một số header giúp giống request thật hơn
        """

        ua = (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/123.0.0.0 Safari/537.36"
        )

        cfg = BrowserConfig(
            headless=True,           # ← chạy ngầm, không hiện browser
            enable_stealth=True,     # ← bật stealth để giảm bị detect
            verbose=False,
            headers={
                "User-Agent": ua,
                "Accept-Language": "en-US,en;q=0.9,vi;q=0.8",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "Referer": "https://www.google.com/"
            },
            java_script_enabled=True,  # phải bật để render nội dung SPA
        )

        log_callback("[crawler] BrowserConfig = headless mode + stealth enabled")
        return cfg

    # ----------------------------------------------------
    # Async crawler thực sự
    # ----------------------------------------------------
    async def _crawl_many(
        self,
        urls: List[str],
        fields: List[str],
        log_callback: LogCallback,
    ) -> List[dict]:
        """
        Chạy AsyncWebCrawler cho nhiều URL.
        Trả về list dict, mỗi dict chỉ chứa những key được yêu cầu trong fields.

        - Dùng BrowserConfig "khó tính" để giảm bị chặn bot
        - Dùng PruningContentFilter + DefaultMarkdownGenerator để:
          giảm noise, bỏ ads/sidebar/footer/related post ở mức tối đa có thể.
        """

        results: List[dict] = []

        # 1. Cấu hình browser "hơi khó tính"
        browser_config = self._create_browser_config(log_callback)

        # 2. Cấu hình Markdown Generator với PruningContentFilter để lọc rác
        pruning_filter = PruningContentFilter()  # dùng cấu hình mặc định (đã tối ưu cho noise)
        md_generator = DefaultMarkdownGenerator(
            content_filter=pruning_filter
        )
        run_config = CrawlerRunConfig(
            markdown_generator=md_generator
        )

        # 3. Chạy AsyncWebCrawler với config trên
        async with AsyncWebCrawler(config=browser_config) as crawler:
            for idx, url in enumerate(urls, start=1):
                try:
                    log_callback(f"[crawler] ({idx}/{len(urls)}) Crawling: {url}")
                    result = await crawler.arun(url=url, config=run_config)

                    # Tạo output cho từng URL
                    item: Dict[str, Any] = {"url": url}
                    html = result.html or ""
                    soup = BeautifulSoup(html, "lxml")

                    # --- markdown (ưu tiên fit_markdown, fallback raw_markdown/string) ---
                    if "markdown" in fields:
                        md_value = ""
                        md_obj = getattr(result, "markdown", None)

                        if isinstance(md_obj, str):
                            # Một số version có thể trả trực tiếp string
                            md_value = md_obj
                        elif md_obj is not None:
                            fit_md = getattr(md_obj, "fit_markdown", None)
                            raw_md = getattr(md_obj, "raw_markdown", None)
                            md_value = fit_md or raw_md or ""
                        item["markdown"] = md_value

                    # --- cleaned_html ---
                    if "cleaned_html" in fields:
                        cleaned = getattr(result, "cleaned_html", None)
                        if not cleaned:
                            cleaned = getattr(result, "html", "") or ""
                        item["cleaned_html"] = cleaned

                    # --- extract_content (map từ result.extracted_content) ---
                    if "extract_content" in fields:
                        text = soup.get_text(" ", strip=True)
                        text = re.sub(r"\s+", " ", text)
                        content = text[:10000]
                        # extracted = getattr(result, "extracted_content", None) or ""
                        item["extract_content"] = content

                    # --- metadata ---
                    if "metadata" in fields:
                        meta = getattr(result, "metadata", None) or {}
                        item["metadata"] = meta

                    log_callback(f"[crawler] ✅ Đã crawl xong: {url}")
                    results.append(item)

                except Exception as e:
                    log_callback(f"[crawler] ❌ Lỗi crawl {url}: {e}")
                    err_item: Dict[str, Any] = {
                        "url": url,
                        "error": str(e),
                    }
                    # Đảm bảo có đủ key trống nếu người dùng yêu cầu
                    if "markdown" in fields:
                        err_item.setdefault("markdown", "")
                    if "cleaned_html" in fields:
                        err_item.setdefault("cleaned_html", "")
                    if "extract_content" in fields:
                        err_item.setdefault("extract_content", "")
                    if "metadata" in fields:
                        err_item.setdefault("metadata", {})
                    results.append(err_item)

        return results


# --------------------------------------------------------
# Adapter: cho backend dùng cho đơn giản
# --------------------------------------------------------
def action_crawler(
    var0: Any,
    var1: Any,
    var2: Any = None,
    log_callback: Optional[LogCallback] = None,
) -> List[dict]:
    """
    Cho backend gọi như cũ:
        output = action_crawler(var0, var1, var2, log_callback)

    - var2: field(s) muốn lấy, ví dụ:
        "markdown"
        "markdown,metadata"
        ["markdown","cleaned_html","metadata"]
    """
    action = CrawlerAction()
    return action.run(
        var0=var0,
        var1=var1,
        var2=var2,
        log_callback=log_callback,
    )
