# config/settings.py
"""
Config nội bộ cho Tool + cấu hình Login.
KHÔNG chứa API key SEO của user (các API đó user tự điền trong Excel).
"""

import os
from pathlib import Path

# Thư mục gốc project
ROOT_DIR = Path(__file__).resolve().parent.parent

# Thư mục DB / log mặc định
DEFAULT_DB_FOLDER = str(ROOT_DIR / "db")
LOG_DIR = str(ROOT_DIR / "logs")

# Số thread mặc định nếu user nhập sai
MAX_THREAD_DEFAULT = 5

# ========== LOGIN CONFIG ==========
BACKEND_LOGIN_URL = "https://seoweb-production.up.railway.app/api/login"
IP_API_URL = "https://api.ipify.org?format=json"

# File lưu cấu hình login (remember me)
LOGIN_CONFIG_FILE = str(ROOT_DIR / "login_config.json")
