# backend/syntax_replace.py
# ============================================================
# SYNTAX REPLACE ENGINE (Chuẩn Auto SEO)
# ============================================================
# - Hỗ trợ replace ~~col.sheet~~
# - Hỗ trợ output của action trước (prepare mở rộng)
# - Hỗ trợ array trong Flow / Dashboard
# - Trả kết quả dưới dạng dữ liệu hợp lệ cho action
# ============================================================

import re
import json
from typing import Dict, Any


# Regex khớp với: ~~tenCot.tenSheet~~
SYNTAX_PATTERN = re.compile(r"~~([A-Za-z0-9_]+)\.([A-Za-z0-9_]+)~~")


def try_parse_json(value):
    """Nếu value là JSON hợp lệ → parse thành list/dict.
       Nếu không → giữ nguyên."""
    if not isinstance(value, str):
        return value
    try:
        return json.loads(value)
    except:
        return value


def replace_value(raw_value: Any, job: Dict[str, Any]):
    """Thay thế syntax trong một giá trị đơn lẻ."""

    # Nếu không phải string → không replace
    if not isinstance(raw_value, str):
        return raw_value

    def _replace(match):
        col = match.group(1)
        sheet = match.group(2)

        # Hiện chỉ hỗ trợ Dashboard
        if sheet.lower() != "dashboard":
            return f"[ERROR: SHEET {sheet} NOT SUPPORTED]"

        if col not in job:
            return f"[ERROR: COLUMN {col} NOT FOUND]"

        raw = job[col]

        # Nếu Dashboard chứa JSON array → trả thẳng
        if isinstance(raw, (list, dict)):
            # Replace inline JSON vào string
            return json.dumps(raw)

        return "" if raw is None else str(raw)

    replaced = SYNTAX_PATTERN.sub(_replace, raw_value)

    # Sau replace, thử parse JSON xem có hợp lệ không
    parsed = try_parse_json(replaced)
    return parsed


def syntax_replace_step(step: Dict[str, Any], job: Dict[str, Any]):
    """Tạo bản sao step và replace syntax trên tất cả field."""

    new_step = {}

    for key, value in step.items():

        # ❗ Output không được replace khi mới start job
        if key.lower() == "output":
            new_step[key] = value
            continue
        
        new_step[key] = replace_value(value, job)

    return new_step
