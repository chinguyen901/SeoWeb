# backend/flow_engine/step_template_loader.py
# =========================================
# Load FLOW & DASHBOARD từ SQLite
# =========================================

import sqlite3
from typing import List, Dict, Any, Callable, Optional


def _log(message: str, log_callback: Optional[Callable[[str], None]] = None):
    if log_callback:
        log_callback(f"[BACKEND_2] {message}")
    else:
        print(f"[BACKEND_2] {message}")


def load_flow_steps_from_db(
    db_path: str,
    log_callback: Optional[Callable[[str], None]] = None,
) -> List[Dict[str, Any]]:
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()

    try:
        cur.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='Flow'"
        )
        if not cur.fetchone():
            msg = "Không tìm thấy bảng 'Flow' trong DB."
            _log(f"[FLOW][ERROR] {msg} | DB={db_path}", log_callback)
            raise Exception(msg)

        cur.execute("SELECT * FROM Flow")
        rows = cur.fetchall()
        col_names = [desc[0] for desc in cur.description]

        flow_steps = [
            {col_names[i]: row[i] for i in range(len(col_names))}
            for row in rows
        ]

        _log(
            f"[FLOW] OK | DB={db_path} | Cols={len(col_names)} {col_names} | Rows={len(rows)}",
            log_callback,
        )

        return flow_steps

    except Exception as e:
        _log(f"[FLOW][EXCEPTION] {e} | DB={db_path}", log_callback)
        raise
    finally:
        conn.close()


def load_jobs_from_db(
    db_path: str,
    log_callback: Optional[Callable[[str], None]] = None,
) -> List[Dict[str, Any]]:
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()

    try:
        cur.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='Dashboard'"
        )
        if not cur.fetchone():
            msg = "Không tìm thấy bảng 'Dashboard' trong DB."
            _log(f"[DASHBOARD][ERROR] {msg} | DB={db_path}", log_callback)
            raise Exception(msg)

        cur.execute("SELECT * FROM Dashboard")
        rows = cur.fetchall()
        col_names = [desc[0] for desc in cur.description]

        jobs = []
        for idx, row in enumerate(rows, start=1):
            job = dict(zip(col_names, row))
            job["_row"] = idx  # số thứ tự dòng
            jobs.append(job)

        _log(
            f"[DASHBOARD] OK | DB={db_path} | Cols={len(col_names)} {col_names} | Rows={len(rows)}",
            log_callback,
        )

        return jobs

    except Exception as e:
        _log(f"[DASHBOARD][EXCEPTION] {e} | DB={db_path}", log_callback)
        raise
    finally:
        conn.close()
