# actions/extract_object.py

import json
import re
from typing import Any, List, Dict, Optional, Tuple, Callable


# ======================================================
# HELPERS: LOG
# ======================================================

def _noop_log(msg: str) -> None:
    """Default log callback (no-op)."""
    pass


# ======================================================
# HELPERS: SOURCE NORMALIZATION
# ======================================================

def _parse_source_by_type(source: Any, data_type: str) -> Any:
    """
    Chuẩn hoá input theo kiểu dữ liệu (theo spec TOOL SEO Web):

    data_type:
      - "json" / "array_json" : parse JSON nếu là string
      - "array_string"        : list string (từ list hoặc từ string nhiều dòng / JSON array)
      - "string"              : giữ nguyên string (dùng regex)

    Trả về object đã chuẩn hoá để tầng dưới xử lý.
    """
    t = (data_type or "").lower().strip()

    # JSON object hoặc JSON array
    if t in ("json", "array_json"):
        if isinstance(source, (dict, list)):
            return source
        if isinstance(source, str):
            s = source.strip()
            try:
                return json.loads(s)
            except Exception:
                return None
        return None

    # Mảng string
    if t == "array_string":
        if isinstance(source, list):
            return [str(x) for x in source]
        if isinstance(source, str):
            s = source.strip()
            # Thử parse JSON array trước
            if s.startswith("[") and s.endswith("]"):
                try:
                    arr = json.loads(s)
                    if isinstance(arr, list):
                        return [str(x) for x in arr]
                except Exception:
                    pass
            # fallback: split theo newline
            return [x for x in source.splitlines() if x.strip()]
        # các kiểu khác -> 1 phần tử string
        return [str(source)]

    # String thô
    if t == "string":
        if source is None:
            return ""
        return str(source)

    # Nếu không rõ type → trả nguyên
    return source


# ======================================================
# HELPERS: PATH PARSER
# ======================================================

def _parse_path_to_tokens(path: str) -> List[str]:
    """
    Biến path kiểu:
      "items[0].field"            → ["items", "[0]", "field"]
      "[*][status==\"ok\"].id"    → ["[*]", "[status==\"ok\"]", "id"]

    Hỗ trợ:
      - key chấm: a.b.c
      - index: [0], [1]
      - wildcard: [*]
      - filter: [status==\"ok\" && score>=10]
    """
    path = (path or "").strip()
    if not path or path == ".":
        return []

    tokens: List[str] = []
    buf: List[str] = []
    i = 0
    n = len(path)

    while i < n:
        c = path[i]
        if c == '.':
            # kết thúc 1 token thường
            if buf:
                tokens.append("".join(buf))
                buf = []
            i += 1
            continue
        if c == '[':
            # kết thúc token thường nếu có
            if buf:
                tokens.append("".join(buf))
                buf = []
            # đọc tới dấu ']' tương ứng (có hỗ trợ lồng [])
            j = i + 1
            depth = 1
            while j < n and depth > 0:
                if path[j] == '[':
                    depth += 1
                elif path[j] == ']':
                    depth -= 1
                j += 1
            tokens.append(path[i:j])  # gồm cả []
            i = j
            continue

        # ký tự thường
        buf.append(c)
        i += 1

    if buf:
        tokens.append("".join(buf))

    return [t for t in tokens if t != ""]


# ======================================================
# HELPERS: FILTER PARSER & EVALUATOR
# ======================================================

FilterCond = Tuple[str, str, Any]  # (field_path, op, expected_value)


def _parse_literal(value_str: str) -> Any:
    """Parse literal trong filter: số / bool / null / string (có hoặc không quotes)."""
    s = value_str.strip()

    if not s:
        return ""

    # quoted string
    if (s[0] == s[-1]) and s[0] in ("'", '"'):
        return s[1:-1]

    # bool
    low = s.lower()
    if low == "true":
        return True
    if low == "false":
        return False
    if low in ("null", "none"):
        return None

    # number
    try:
        if "." in s:
            return float(s)
        return int(s)
    except Exception:
        pass

    # fallback: raw string
    return s


def _parse_single_condition(cond: str) -> Optional[FilterCond]:
    """
    Parse 1 condition dạng:
      field == 10
      field >= 5
      field contains "abc"

    Hỗ trợ op:
      ==, !=, >, >=, <, <=, contains, ~, ~=  (treated như contains).
    """
    cond = cond.strip()
    if not cond:
        return None

    # Regex: field (tên field, cho phép a.b.c) + op + value
    m = re.match(
        r"""^\s*
        (?P<field>[A-Za-z0-9_.]+)
        \s*
        (?P<op>==|!=|>=|<=|>|<|contains|~=|~)
        \s*
        (?P<value>.+?)
        \s*$""",
        cond,
        re.VERBOSE,
    )
    if not m:
        return None

    field = m.group("field")
    op = m.group("op")
    value_raw = m.group("value")
    value = _parse_literal(value_raw)
    return (field, op, value)


def _parse_filter_expr(expr: str) -> List[FilterCond]:
    """
    Parse filter dạng:
      field1 == 1 && field2 contains "abc"
    -> list các điều kiện AND.
    """
    expr = (expr or "").strip()
    if not expr:
        return []

    parts = [p for p in re.split(r"\s*&&\s*", expr) if p.strip()]
    conds: List[FilterCond] = []
    for p in parts:
        c = _parse_single_condition(p)
        if c is not None:
            conds.append(c)
    return conds


def _get_value_by_field_path(obj: Any, field_path: str) -> Any:
    """
    Lấy giá trị từ obj theo field_path dạng: "a.b.c".
    Chỉ dùng cho dict lồng nhau.
    """
    if not isinstance(obj, dict):
        return None
    cur: Any = obj
    for part in field_path.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return None
        cur = cur[part]
    return cur


def _eval_condition(actual: Any, op: str, expected: Any) -> bool:
    """So sánh actual với expected theo toán tử op."""
    # xử lý None: chỉ == / != có ý nghĩa rõ ràng
    if actual is None:
        if op == "==":
            return expected is None
        if op == "!=":
            return expected is not None
        return False

    # contains / ~ / ~=  → kiểm tra chứa
    if op in ("contains", "~", "~="):
        if isinstance(actual, list):
            return expected in actual
        return str(expected) in str(actual)

    # chuyển numeric nếu có thể, nếu không thì so sánh string
    def to_number(x: Any) -> Optional[float]:
        try:
            return float(x)
        except Exception:
            return None

    if op in (">", "<", ">=", "<="):
        a_num = to_number(actual)
        b_num = to_number(expected)
        if a_num is not None and b_num is not None:
            if op == ">":
                return a_num > b_num
            if op == "<":
                return a_num < b_num
            if op == ">=":
                return a_num >= b_num
            if op == "<=":
                return a_num <= b_num
        # fallback: compare string
        a_str = str(actual)
        b_str = str(expected)
        if op == ">":
            return a_str > b_str
        if op == "<":
            return a_str < b_str
        if op == ">=":
            return a_str >= b_str
        if op == "<=":
            return a_str <= b_str

    # == / !=
    if op == "==":
        # nếu cả 2 cùng numeric được → so sánh numeric
        a_num = to_number(actual)
        b_num = to_number(expected)
        if a_num is not None and b_num is not None:
            return a_num == b_num
        return str(actual) == str(expected)

    if op == "!=":
        a_num = to_number(actual)
        b_num = to_number(expected)
        if a_num is not None and b_num is not None:
            return a_num != b_num
        return str(actual) != str(expected)

    # nếu op không support → cho fail
    return False


def _matches_filter(node: Any, expr: str) -> bool:
    """Kiểm tra 1 node (thường là dict) có thoả filter expr hay không."""
    expr = (expr or "").strip()
    if not expr:
        return True

    conds = _parse_filter_expr(expr)
    if not conds:
        # filter không parse được -> mặc định fail
        return False

    # Nếu node không phải dict -> không hỗ trợ filter
    if not isinstance(node, dict):
        return False

    for field_path, op, expected in conds:
        actual = _get_value_by_field_path(node, field_path)
        if not _eval_condition(actual, op, expected):
            return False

    return True


# ======================================================
# CORE: JSON / ARRAY_JSON PATH WALKER
# ======================================================

def _walk_json_path(source: Any, path: str) -> List[Any]:
    """
    Đi theo path trên source (dict hoặc list) và trả về list node cuối cùng.

    Cơ chế:
      - Token thường  : key của dict
      - Token "[n]"   : index list
      - Token "[*]"   : wildcard list
      - Token "[cond]": filter theo cond, cond áp lên:
                        - nếu node là list -> từng phần tử trong list
                        - nếu node là dict -> node đó
    """
    path = (path or "").strip()
    if not path or path == ".":
        return [source]

    tokens = _parse_path_to_tokens(path)
    if not tokens:
        return [source]

    nodes: List[Any] = [source]

    for token in tokens:
        if not nodes:
            break

        # Bracket token
        if token.startswith("[") and token.endswith("]"):
            inside = token[1:-1].strip()
            if not inside:
                continue

            new_nodes: List[Any] = []

            # [*] -> wildcard
            if inside == "*":
                for node in nodes:
                    if isinstance(node, list):
                        new_nodes.extend(node)
                nodes = new_nodes
                continue

            # [index]
            if inside.isdigit():
                idx = int(inside)
                for node in nodes:
                    if isinstance(node, list) and 0 <= idx < len(node):
                        new_nodes.append(node[idx])
                nodes = new_nodes
                continue

            # [cond] (filter)
            expr = inside
            for node in nodes:
                if isinstance(node, list):
                    for item in node:
                        if _matches_filter(item, expr):
                            new_nodes.append(item)
                else:
                    if _matches_filter(node, expr):
                        new_nodes.append(node)
            nodes = new_nodes
            continue

        # Key token
        key = token
        new_nodes = []
        for node in nodes:
            if isinstance(node, dict) and key in node:
                new_nodes.append(node[key])
        nodes = new_nodes

    return nodes


def _extract_from_json_like(
    source: Any,
    path: str,
    mode: str,
) -> Any:
    """
    Xử lý cho kiểu json / array_json theo đúng 3 mode (spec TOOL):

      - single : trả 1 giá trị (scalar hoặc object)
      - multi  : list giá trị đơn; dict/list sẽ được json.dumps thành string
      - explode: trả list "raw node", tầng trên sẽ json.dumps từng phần tử.
    """
    mode_norm = (mode or "single").lower().strip()
    path = (path or "").strip()

    # Nếu source None → không có gì để đi path
    if source is None:
        if mode_norm == "single":
            return None
        return []

    # Bước 1: đi path
    if not path or path == ".":
        nodes = [source]
    else:
        nodes = _walk_json_path(source, path)

    # Bước 2: xử lý theo mode
    if mode_norm == "single":
        if not nodes:
            return None
        return nodes[0]

    if mode_norm == "multi":
        out: List[Any] = []
        for v in nodes:
            # nếu là dict/list -> stringify để không trả "object"
            if isinstance(v, (dict, list)):
                try:
                    out.append(json.dumps(v, ensure_ascii=False))
                except Exception:
                    out.append(str(v))
            else:
                out.append(v)
        return out

    # explode -> để raw node, tầng trên sẽ json.dumps
    return nodes


# ======================================================
# CORE: ARRAY_STRING
# ======================================================

def _extract_from_array_string(
    source: List[str],
    path: str,
    mode: str,
) -> Any:
    """
    Xử lý cho array_string.

    - single: "[index]" → 1 giá trị
              "" hoặc "[*]" → phần tử đầu
    - multi : "[*]" hoặc "" → toàn bộ list
              "[index]"      → [1 phần tử]
    - explode: behave giống multi;
               sau đó tầng trên sẽ stringify nếu cần.
    """
    mode_norm = (mode or "single").lower().strip()
    path = (path or "").strip()

    if not isinstance(source, list):
        source = [str(source)]

    # mặc định path rỗng -> [*] (tức lấy tất)
    if path == "":
        path = "[*]"

    # [index]
    m_index = re.match(r"^\[(\d+)\]$", path)
    if m_index:
        idx = int(m_index.group(1))
        val = source[idx] if 0 <= idx < len(source) else None
        if mode_norm == "single":
            return val
        else:  # multi / explode -> list
            return [val] if val is not None else []

    # [*]
    if path == "[*]":
        if mode_norm == "single":
            return source[0] if source else None
        else:
            # multi / explode
            return list(source)

    # path không hợp lệ -> rỗng
    if mode_norm == "single":
        return None
    else:
        return []


# ======================================================
# CORE: STRING + REGEX
# ======================================================

def _extract_from_string_regex(
    source: str,
    pattern: str,
    mode: str,
) -> Any:
    """
    Xử lý cho string với regex.

      - single:
          + match đầu tiên
          + nếu có:
              * 0 hoặc 1 group  → string (group1 hoặc full)
              * >1 group / named group → JSON object chứa group
      - multi :
          + tất cả match
          + mỗi match là 1 giá trị đơn (ưu tiên group1, nếu không có group → full)
      - explode:
          + nhiều JSON object, mỗi object đại diện cho 1 match:
              { "group1": "...", "group2": "..." }
          + nếu có named group → dùng tên group thay vì group1, group2
    """
    mode_norm = (mode or "single").lower().strip()
    pattern = pattern or ""
    s = source or ""

    if not pattern:
        if mode_norm == "single":
            return s
        elif mode_norm == "multi":
            return [s]
        else:  # explode
            return [{"value": s}]

    try:
        regex = re.compile(pattern, re.MULTILINE | re.DOTALL)
    except re.error:
        # pattern không hợp lệ
        if mode_norm == "single":
            return None
        elif mode_norm == "multi":
            return []
        else:
            return []

    if mode_norm == "single":
        m = regex.search(s)
        if not m:
            return None

        named = m.groupdict()
        if named:
            # nếu chỉ có 1 named group -> trả luôn giá trị
            if len(named) == 1:
                return next(iter(named.values()))
            return named

        # không có named group
        if m.lastindex is None or m.lastindex <= 0:
            return m.group(0)

        if m.lastindex == 1:
            return m.group(1)

        # >1 group -> trả object group1, group2, ...
        obj = {}
        for i in range(1, m.lastindex + 1):
            obj[f"group{i}"] = m.group(i)
        return obj

    elif mode_norm == "multi":
        results: List[Any] = []
        for m in regex.finditer(s):
            # ưu tiên group1, nếu không có group thì full match
            if m.lastindex and m.lastindex >= 1:
                results.append(m.group(1))
            else:
                results.append(m.group(0))
        return results

    else:  # explode
        objects: List[Dict[str, Any]] = []
        for m in regex.finditer(s):
            named = m.groupdict()
            if named:
                obj = dict(named)
            elif m.lastindex and m.lastindex >= 1:
                obj = {f"group{i}": m.group(i) for i in range(1, m.lastindex + 1)}
            else:
                obj = {"group1": m.group(0)}
            objects.append(obj)

        # explode chung: tầng ngoài sẽ json.dumps từng object
        return objects


# ======================================================
# ENTRY CHÍNH (ACTION)
# ======================================================

def extract_object(
    var0: Any,
    var1: Any,
    var2: Any,
    var3: Any,
    var4: Any,
    log_callback: Optional[Callable[[str], None]] = None,
) -> Any:
    """
    ENTRY chính cho ACTION extract_object cho TOOL SEO Web.

    Tham số:
      - var0: const 0 hoặc 1 (hiện tại không dùng trong logic, để dành
              cho việc đặt tên file / row index nếu cần trong backend).
      - var1: source_object
              (json / array_json / array_string / string)
      - var2: path
      - var3: mode  (single / multi / explode)
      - var4: data_type_source
              (json / array_json / array_string / string
               hoặc list các kiểu này cho nhiều cấu hình song song)

    Hỗ trợ:
      - Trường hợp đơn (var4 là string):
            -> xử lý 1 source, trả 1 kết quả.
      - Trường hợp nhiều (var4 là list):
            -> duyệt theo index i, kết quả là list cùng chiều với var4.
               + var1, var2, var3 nếu không phải list thì sẽ được broadcast.
               + nếu var1 là list và len(var1) == len(var4) thì map theo index.
    """
    log = log_callback or _noop_log

    # --------------------------------------------------
    # CASE 1: var4 là SCALAR -> 1 cấu hình duy nhất
    # --------------------------------------------------
    if not isinstance(var4, list):
        data_type = (var4 or "").lower().strip()
        mode = (var3 or "single")
        path = var2

        src = _parse_source_by_type(var1, data_type)
        log(f"[ACTION=extract_object] single type={data_type} mode={mode} path={path}")

        if data_type in ("json", "array_json"):
            out = _extract_from_json_like(src, str(path or ""), str(mode or "single"))
        elif data_type == "array_string":
            out = _extract_from_array_string(
                src if isinstance(src, list) else [str(src)],
                str(path or ""),
                str(mode or "single"),
            )
        elif data_type == "string":
            out = _extract_from_string_regex(
                str(src or ""),
                str(path or ""),
                str(mode or "single"),
            )
        else:
            # kiểu không xác định -> trả nguyên source
            out = src

        mode_norm = (mode or "").lower().strip()
        # explode -> chuẩn hoá output thành list JSON string (chuẩn spec)
        if mode_norm == "explode":
            if isinstance(out, list):
                json_list: List[str] = []
                for item in out:
                    try:
                        json_list.append(json.dumps(item, ensure_ascii=False))
                    except Exception:
                        json_list.append(
                            json.dumps({"value": str(item)}, ensure_ascii=False)
                        )
                result = json_list
            else:
                try:
                    result = [json.dumps(out, ensure_ascii=False)]
                except Exception:
                    result = [json.dumps({"value": str(out)}, ensure_ascii=False)]
        else:
            result = out

        return result

    # --------------------------------------------------
    # CASE 2: var4 là LIST -> nhiều cấu hình song song
    # --------------------------------------------------

    data_types: List[str] = [str(dt or "").lower().strip() for dt in var4]

    # Chuẩn hoá path (var2), mode (var3), source (var1)
    n = len(data_types)

    # paths
    if isinstance(var2, list):
        if var2:
            paths = list(var2) + [var2[-1]] * max(0, n - len(var2))
        else:
            paths = [None] * n
    else:
        paths = [var2] * n

    # modes
    if isinstance(var3, list):
        if var3:
            modes = list(var3) + [var3[-1]] * max(0, n - len(var3))
        else:
            modes = ["single"] * n
    else:
        modes = [var3] * n

    # sources
    if isinstance(var1, list) and len(var1) == n:
        sources = list(var1)
    else:
        sources = [var1] * n

    outputs: List[Any] = []

    for i in range(n):
        dt = data_types[i]
        mode = modes[i] if i < len(modes) else modes[-1]
        path = paths[i] if i < len(paths) else paths[-1]
        src_raw = sources[i] if i < len(sources) else sources[-1]

        src = _parse_source_by_type(src_raw, dt)

        log(
            f"[ACTION=extract_object] i={i} type={dt} mode={mode} path={path}"
        )

        if dt in ("json", "array_json"):
            out = _extract_from_json_like(src, str(path or ""), str(mode or "single"))
        elif dt == "array_string":
            out = _extract_from_array_string(
                src if isinstance(src, list) else [str(src)],
                str(path or ""),
                str(mode or "single"),
            )
        elif dt == "string":
            out = _extract_from_string_regex(
                str(src or ""),
                str(path or ""),
                str(mode or "single"),
            )
        else:
            out = src

        mode_norm = (mode or "").lower().strip()
        if mode_norm == "explode":
            if isinstance(out, list):
                json_list: List[str] = []
                for item in out:
                    try:
                        json_list.append(json.dumps(item, ensure_ascii=False))
                    except Exception:
                        json_list.append(
                            json.dumps({"value": str(item)}, ensure_ascii=False)
                        )
                outputs.append(json_list)
            else:
                try:
                    outputs.append([json.dumps(out, ensure_ascii=False)])
                except Exception:
                    outputs.append(
                        [json.dumps({"value": str(out)}, ensure_ascii=False)]
                    )
        else:
            outputs.append(out)

    return outputs
