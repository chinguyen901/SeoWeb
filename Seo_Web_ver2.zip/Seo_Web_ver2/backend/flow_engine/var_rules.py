# backend/flow_engine/var_rules.py
from typing import Any, Dict, List, Callable, Optional


def validate_vars(step_ready: Dict[str, Any], log_callback: Optional[Callable[[str], None]] = None) -> List[str]:
    raw_var0 = step_ready.get("Var0")

    # Fix lỗi Excel convert: 1 → 1.0 (float)
    try:
        if isinstance(raw_var0, float) and raw_var0.is_integer():
            raw_var0 = int(raw_var0)
    except Exception:
        pass

    var0 = str(raw_var0).strip()
    errors: List[str] = []

    # Lấy action để tuỳ biến rule (extract_object cần cho phép dict)
    action = str(step_ready.get("Action") or "").lower()

    # Gom nhóm Var1..VarX (bỏ Var0)
    vars_group = []
    for key, value in step_ready.items():
        if not key.startswith("Var"):
            continue
        if key == "Var0":
            continue
        vars_group.append((key, value))

    # MODE 1 → SINGLE
    if var0 == "1":
        for name, value in vars_group:
            if value is None:
                continue

            if isinstance(value, str):
                continue

            if action == "extract_object" and isinstance(value, dict):
                continue

            if isinstance(value, list):
                if len(value) != 1:
                    errors.append(
                        f"{name} phải là mảng 1 phần tử, nhưng nhận list {len(value)} phần tử"
                    )
                continue

            errors.append(
                f"{name} phải là list 1 phần tử hoặc string, nhận kiểu {type(value)}"
            )

        return errors

    # MODE 0 → MULTI
    if var0 == "0":
        for name, value in vars_group:
            if value is None:
                continue

            if isinstance(value, str):
                errors.append(
                    f"{name} phải là LIST >= 2 phần tử, nhưng nhận STRING: {value}"
                )
                continue

            if isinstance(value, list):
                if len(value) < 2:
                    errors.append(
                        f"{name} phải là LIST >= 2 phần tử, nhưng chỉ có {len(value)} phần tử"
                    )
                continue

            errors.append(
                f"{name} phải là LIST >= 2 phần tử, nhận kiểu {type(value)}"
            )

        return errors

    # Var0 không phải 0 hoặc 1
    return [f"Var0 chỉ cho phép 0 hoặc 1, nhận: {var0}"]
