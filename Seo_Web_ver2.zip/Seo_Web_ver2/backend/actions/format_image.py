# actions/format_image.py

import json
from io import BytesIO
from pathlib import Path
from typing import Any, Dict, Optional, Callable, List

from typing import TYPE_CHECKING

try:
    from PIL import Image
except ImportError:
    Image = None  # <-- Runtime fallback, nhưng Pylance vẫn biết Image là module khi TYPE_CHECKING

if TYPE_CHECKING:
    from PIL import Image as PILImage

def _noop_log(msg: str) -> None:
    """Default log callback (no-op)."""
    pass


# ======================================================
# HELPERS
# ======================================================

def _normalize_json_dict(raw: Any) -> Dict[str, Any]:
    """
    Chuẩn hoá input (var4/var5/var6) về dict:

    Cho phép:
      - dict: dùng luôn
      - str : cố parse JSON
      - None / lỗi: {}
    """
    if isinstance(raw, dict):
        return dict(raw)

    if isinstance(raw, str):
        s = raw.strip()
        if not s:
            return {}
        try:
            obj = json.loads(s)
            if isinstance(obj, dict):
                return obj
        except Exception:
            return {}

    return {}


def _ensure_path(path_str: str) -> Path:
    """
    Chuẩn hoá path string → Path object.
    """
    return Path(path_str).expanduser()


def _list_image_files(root: Path) -> List[Path]:
    """
    Liệt kê tất cả file ảnh trong 1 folder (jpg/png/webp).
    Không đệ quy; chỉ lấy cùng cấp.
    """
    exts = {".jpg", ".jpeg", ".png", ".webp"}
    files: List[Path] = []
    for p in root.iterdir():
        if p.is_file() and p.suffix.lower() in exts:
            files.append(p)
    return files


def _resolve_input_images(path_local: str) -> List[Path]:
    """
    Từ var1 (path_local) xác định danh sách file ảnh cần xử lý:

    - Nếu là file → [file] (nếu tồn tại)
    - Nếu là folder → list tất cả file ảnh trong folder
    - Nếu không tồn tại → []
    """
    root = _ensure_path(path_local)
    if root.is_file():
        return [root]
    if root.is_dir():
        return _list_image_files(root)
    return []


def _resolve_output_path(base_output: str, input_path: Path, index: int = 1) -> Path:
    """
    Xác định path output cuối:

    - base_output:
        - Nếu là file (có suffix) → dùng như template:
            + ảnh 1: y hệt
            + ảnh 2+: chèn thêm _{index} trước suffix.
        - Nếu là folder           → lưu vào folder với tên gốc + _{index} (nếu cần).
    """
    base = _ensure_path(base_output)

    if base.suffix.lower() in {".jpg", ".jpeg", ".png", ".webp"}:
        if index == 1:
            out_path = base
        else:
            out_path = base.with_name(f"{base.stem}_{index}{base.suffix}")
    else:
        base.mkdir(parents=True, exist_ok=True)
        # Giữ tên file gốc (input_path), thêm _{index} nếu cần
        suffix = input_path.suffix
        if index == 1:
            out_path = base / input_path.name
        else:
            out_path = base / f"{input_path.stem}_{index}{suffix}"

    out_path.parent.mkdir(parents=True, exist_ok=True)
    return out_path

def _load_template(path_template: Optional[str], log: Callable[[str], None]) -> Optional["PILImage.Image"]:
    """
    Load ảnh template (frame) nếu path_template có và tồn tại.
    """
    if not path_template:
        return None

    p = _ensure_path(path_template)
    if not p.is_file():
        log(f"[ACTION=format_image] ⚠ path_template không tồn tại: {p}")
        return None

    try:
        template = Image.open(p).convert("RGBA")
        log(f"[ACTION=format_image] Đã load template: {p}")
        return template
    except Exception as e:
        log(f"[ACTION=format_image] ❌ Không load được template {p}: {e}")
        return None


def _apply_frame(
    src_img: "PILImage.Image",
    template_img: Optional["PILImage.Image"],
    cfg_template: Dict[str, Any],
    log: Callable[[str], None],
) -> "PILImage.Image":
    """
    Áp dụng frame (template) lên ảnh src.

    Logic:
      - Nếu không có template → trả lại src ảnh gốc.
      - outer_size: kích thước final canvas.
      - inner_size: kích thước vùng hiển thị ảnh gốc.
      - offset    : độ lệch tâm của vùng ảnh gốc so với center.

    Thao tác:
      1. Resize template về outer_size (nếu outer_size >0).
      2. Tạo canvas cùng size template.
      3. Resize src_img để fit vào inner_size, giữ tỉ lệ.
      4. Paste src_img vào vị trí tính từ inner_size + offset.
      5. Paste template lên trên (frame overlay).
    """
    if template_img is None:
        # Không dùng frame
        return src_img.copy()

    outer_cfg = cfg_template.get("outer_size") or {}
    inner_cfg = cfg_template.get("inner_size") or {}
    offset_cfg = cfg_template.get("offset") or {}

    outer_w = int(outer_cfg.get("width") or 0)
    outer_h = int(outer_cfg.get("height") or 0)
    inner_w = int(inner_cfg.get("width") or 0)
    inner_h = int(inner_cfg.get("height") or 0)
    off_x = int(offset_cfg.get("x") or 0)
    off_y = int(offset_cfg.get("y") or 0)

    tmpl = template_img.copy()

    # Nếu outer_size có set → resize template
    if outer_w > 0 and outer_h > 0:
        tmpl = tmpl.resize((outer_w, outer_h), Image.LANCZOS)
    else:
        outer_w, outer_h = tmpl.size

    # Nếu inner_size không set → mặc định 80% outer
    if inner_w <= 0 or inner_h <= 0:
        inner_w = int(outer_w * 0.8)
        inner_h = int(outer_h * 0.8)

    # Tính toạ độ vùng inner box (center + offset)
    inner_x = (outer_w - inner_w) // 2 + off_x
    inner_y = (outer_h - inner_h) // 2 + off_y

    # Tạo canvas RGBA
    canvas = Image.new("RGBA", (outer_w, outer_h), (0, 0, 0, 0))

    # Resize src_img để fit vào inner_size, giữ tỉ lệ
    src = src_img.convert("RGBA")
    src_w, src_h = src.size

    scale_w = inner_w / src_w
    scale_h = inner_h / src_h
    scale = min(scale_w, scale_h)
    if scale <= 0:
        scale = 1.0

    new_w = max(1, int(src_w * scale))
    new_h = max(1, int(src_h * scale))
    src_resized = src.resize((new_w, new_h), Image.LANCZOS)

    # Căn giữa src_resized trong inner box
    paste_x = inner_x + (inner_w - new_w) // 2
    paste_y = inner_y + (inner_h - new_h) // 2

    canvas.paste(src_resized, (paste_x, paste_y), src_resized)

    # Paste template lên trên (frame overlay)
    canvas.alpha_composite(tmpl)

    return canvas


def _optimize_image(
    img: "PILImage.Image",
    cfg_opt: Dict[str, Any],
    log: Callable[[str], None],
) -> bytes:
    """
    Áp dụng tối ưu hoá:
      - resize (giữ tỉ lệ nếu keep_ratio)
      - quality
      - max_size_kb (approx, giảm quality dần)
      - format (jpg/png/webp)

    Trả về:
      - bytes của ảnh sau cùng (để ghi file).
    """
    resize_cfg = cfg_opt.get("resize") or {}
    target_w = int(resize_cfg.get("width") or 0)
    target_h = int(resize_cfg.get("height") or 0)
    keep_ratio = bool(resize_cfg.get("keep_ratio", True))

    quality = int(cfg_opt.get("quality") or 85)
    quality = max(1, min(quality, 100))

    max_size_kb = int(cfg_opt.get("max_size_kb") or 0)
    img_format = (cfg_opt.get("format") or "jpg").lower()

    # Map format → Pillow
    if img_format in {"jpg", "jpeg"}:
        pil_format = "JPEG"
    elif img_format == "png":
        pil_format = "PNG"
    elif img_format == "webp":
        pil_format = "WEBP"
    else:
        pil_format = "JPEG"
        img_format = "jpg"

    # Resize nếu cần
    img_proc = img.copy()
    if target_w > 0 or target_h > 0:
        w0, h0 = img_proc.size
        if keep_ratio:
            # Tính scale theo chiều có hạn
            scale_w = target_w / w0 if target_w > 0 else None
            scale_h = target_h / h0 if target_h > 0 else None

            scales = [s for s in (scale_w, scale_h) if s is not None]
            if scales:
                scale = min(scales)
                new_w = max(1, int(w0 * scale))
                new_h = max(1, int(h0 * scale))
                img_proc = img_proc.resize((new_w, new_h), Image.LANCZOS)
        else:
            new_w = target_w if target_w > 0 else img_proc.size[0]
            new_h = target_h if target_h > 0 else img_proc.size[1]
            img_proc = img_proc.resize((new_w, new_h), Image.LANCZOS)

    # JPEG không hỗ trợ alpha
    if pil_format == "JPEG" and img_proc.mode in ("RGBA", "LA"):
        bg = Image.new("RGB", img_proc.size, (255, 255, 255))
        bg.paste(img_proc, mask=img_proc.split()[-1])
        img_proc = bg
    elif pil_format == "JPEG" and img_proc.mode != "RGB":
        img_proc = img_proc.convert("RGB")

    # Lưu thử vào buffer
    def _save_to_bytes(q: int) -> bytes:
        buf = BytesIO()
        save_kwargs = {}
        if pil_format in {"JPEG", "WEBP"}:
            save_kwargs["quality"] = q
        img_proc.save(buf, format=pil_format, **save_kwargs)
        return buf.getvalue()

    img_bytes = _save_to_bytes(quality)

    # Nếu có max_size_kb → giảm quality dần
    if max_size_kb > 0:
        max_bytes = max_size_kb * 1024
        q = quality
        while len(img_bytes) > max_bytes and q > 20:
            q -= 5
            log(
                f"[ACTION=format_image] Giảm quality xuống {q} "
                f"vì kích thước={len(img_bytes)/1024:.1f}KB > {max_size_kb}KB"
            )
            img_bytes = _save_to_bytes(q)

    return img_bytes


def _write_seo_sidecar(
    image_path: Path,
    cfg_seo: Dict[str, Any],
    log: Callable[[str], None],
) -> None:
    """
    Ghi metadata SEO ra file sidecar .seo.json cùng tên ảnh.

    Ví dụ:
      - ảnh:  /path/to/img_1.jpg
      - sidecar: /path/to/img_1.jpg.seo.json

    Làm vậy:
      - Dễ debug
      - Không phá EXIF/IPTC/XMP trong ảnh gốc
      - Dùng được cho pipeline build web, crawler khác đọc metadata này
    """
    if not cfg_seo:
        return

    sidecar_path = image_path.with_suffix(image_path.suffix + ".seo.json")
    try:
        sidecar_path.write_text(
            json.dumps(cfg_seo, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        log(f"[ACTION=format_image] ✅ Đã ghi SEO sidecar: {sidecar_path}")
    except Exception as e:
        log(f"[ACTION=format_image] ❌ Lỗi khi ghi SEO sidecar: {e}")


# ======================================================
# ACTION CHÍNH
# ======================================================

def format_image(
    var0: Any,  # const 0/1 (hiện chưa dùng; future: multi mode, parallel, v.v.)
    var1: Any,  # path_local: ảnh nguồn (file hoặc folder)
    var2: Any,  # path_local_final: nơi lưu ảnh sau khi định dạng
    var3: Any,  # path_template: frame/template (file)
    var4: Any,  # config_template (outer_size, inner_size, offset)
    var5: Any,  # config_optimize (resize, quality, max_size_kb, format)
    var6: Any,  # config_seo (metadata SEO, optional)
    log_callback: Optional[Callable[[str], None]] = None,
) -> List[str]:
    """
    ACTION: format_image

    Cú pháp:
        output = format_image(var0, var1, var2, var3, var4, var5, var6)

    Tham số:
      - var0: const 0 hoặc 1 (chưa dùng trong logic)
      - var1: path_local → đường dẫn ảnh ở local cần định dạng
               + Nếu là file   → xử lý file đó
               + Nếu là folder → xử lý toàn bộ ảnh trong folder (.jpg/.jpeg/.png/.webp)
      - var2: path_local_final → nơi lưu ảnh sau khi định dạng
               + Có thể là file hoặc folder

      - var3: path_template → đường dẫn đến ảnh frame (overlay).
               + Nếu rỗng hoặc không tồn tại → không dùng frame.

      - var4: config_template (cho phép để trống), dạng:

            {
              "outer_size": { "width": 1600, "height": 900 },
              "inner_size": { "width": 1200, "height": 800 },
              "offset": { "x": 0, "y": 0 }
            }

        Thuộc tính:
          outer_size.width / height : kích thước canvas ngoài cùng
          inner_size.width / height : vùng chứa ảnh gốc
          offset.x / y              : độ lệch tâm vùng ảnh gốc so với center

      - var5: config_optimize (cho phép để trống), dạng:

            {
              "resize": { "width": 0, "height": 0, "keep_ratio": true },
              "quality": 85,
              "max_size_kb": 500,
              "format": "jpg"
            }

        Thuộc tính:
          resize.width / height : kích thước target
          keep_ratio            : giữ tỉ lệ hay không
          quality               : 1–100
          max_size_kb           : giới hạn dung lượng tối đa (nếu >0)
          format                : "jpg" / "png" / "webp"

      - var6: config_seo (cho phép để trống), dạng:

            {
              "location": {...},
              "categories": {...},
              "contact": {...},
              "source_description": {...},
              "date": {...}
            }

        ✅ Ở đây implement:
          - Ghi metadata SEO ra file sidecar .seo.json cùng tên ảnh.

    Trả về:
      - List[str]: danh sách đường dẫn ảnh đã được format (có thể rỗng nếu lỗi).
    """
    log = log_callback or _noop_log

    if Image is None:
        log("[ACTION=format_image] ❌ Thiếu thư viện Pillow. Hãy cài: pip install pillow")
        return []

    path_local = ("" if var1 is None else str(var1).strip())
    path_final = ("" if var2 is None else str(var2).strip())
    path_template = ("" if var3 is None else str(var3).strip())

    if not path_local:
        log("[ACTION=format_image] ❌ var1 (path_local) rỗng.")
        return []

    if not path_final:
        log("[ACTION=format_image] ⚠ var2 (path_local_final) rỗng, auto dùng './formatted_images'.")
        path_final = "./formatted_images"

    cfg_template = _normalize_json_dict(var4)
    cfg_optimize = _normalize_json_dict(var5)
    cfg_seo = _normalize_json_dict(var6)

    # Load danh sách ảnh input
    input_images = _resolve_input_images(path_local)
    if not input_images:
        log("[ACTION=format_image] ❌ Không tìm thấy ảnh nào từ path_local.")
        return []

    log(f"[ACTION=format_image] Tìm thấy {len(input_images)} ảnh để xử lý.")

    # Load template (frame) nếu có
    template_img = _load_template(path_template, log)

    # Nếu config_optimize rỗng → dùng default
    if not cfg_optimize:
        cfg_optimize = {
            "resize": {"width": 0, "height": 0, "keep_ratio": True},
            "quality": 85,
            "max_size_kb": 0,
            "format": "jpg",
        }

    output_paths: List[str] = []

    for idx, in_path in enumerate(input_images, start=1):
        log(f"[ACTION=format_image] ({idx}/{len(input_images)}) Xử lý: {in_path}")

        try:
            src_img = Image.open(in_path)
        except Exception as e:
            log(f"[ACTION=format_image] ❌ Không mở được ảnh nguồn {in_path}: {e}")
            continue

        # 1. Áp dụng frame nếu có
        try:
            img_with_frame = _apply_frame(
                src_img=src_img,
                template_img=template_img,
                cfg_template=cfg_template,
                log=log,
            )
        except Exception as e:
            log(f"[ACTION=format_image] ❌ Lỗi khi áp dụng frame cho {in_path}: {e}")
            continue

        # 2. Tối ưu hoá (resize, quality, format, max_size_kb)
        try:
            img_bytes = _optimize_image(
                img=img_with_frame,
                cfg_opt=cfg_optimize,
                log=log,
            )
        except Exception as e:
            log(f"[ACTION=format_image] ❌ Lỗi khi tối ưu hoá ảnh {in_path}: {e}")
            continue

        # 3. Xác định output path & ghi file
        out_path = _resolve_output_path(path_final, in_path, index=idx)
        try:
            out_p = _ensure_path(str(out_path))
            out_p.parent.mkdir(parents=True, exist_ok=True)
            out_p.write_bytes(img_bytes)
            log(f"[ACTION=format_image] ✅ Đã lưu ảnh sau khi format: {out_p}")
            output_paths.append(str(out_p.resolve()))
        except Exception as e:
            log(f"[ACTION=format_image] ❌ Lỗi khi lưu ảnh {out_path}: {e}")
            continue

        # 4. Ghi metadata SEO sidecar nếu có
        try:
            if cfg_seo:
                _write_seo_sidecar(out_p, cfg_seo, log)
        except Exception as e:
            log(f"[ACTION=format_image] ❌ Lỗi khi ghi SEO sidecar cho {out_p}: {e}")

    log(f"[ACTION=format_image] ✅ Tổng số ảnh xử lý thành công: {len(output_paths)}")
    return output_paths
