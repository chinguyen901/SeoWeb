# db/bigdb.py
"""
Quản lý kết nối SQLite + khởi tạo Big DB.

Big DB này dùng để:
- Lưu FLOW_STEPS (template step từ Excel)
- Lưu DASHBOARD_ROWS (mỗi dòng Dashboard = 1 job)
- Lưu LOG (log theo job / session)

Mỗi lần user chọn 1 file Excel → bạn có thể tạo 1 "session_id"
và lưu chung vào Big DB này (hoặc dùng db riêng cho file Excel – tuỳ bạn).
"""

import sqlite3
from pathlib import Path
from typing import Optional

from config.settings import DB_PATH  # DB_PATH = bigdb.sqlite3 (gợi ý ở settings.py)


def get_connection(db_path: Optional[str] = None) -> sqlite3.Connection:
    """
    Tạo connection tới SQLite.
    - db_path = None → dùng DB_PATH mặc định.
    - Tự tạo thư mục cha nếu chưa tồn tại.
    - Set row_factory = sqlite3.Row cho tiện đọc.
    """
    if db_path is None:
        db_path = DB_PATH

    db_file = Path(db_path)
    db_file.parent.mkdir(parents=True, exist_ok=True)

    conn = sqlite3.connect(str(db_file))
    conn.row_factory = sqlite3.Row
    return conn


def init_bigdb(db_path: Optional[str] = None) -> sqlite3.Connection:
    """
    Khởi tạo Big DB (nếu chưa có bảng).
    Trả về connection để tái sử dụng nếu muốn.
    """
    conn = get_connection(db_path)
    cur = conn.cursor()

    # Bảng FLOW_STEPS: lưu template step từ Excel
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS flow_steps (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT NOT NULL,
            step INTEGER NOT NULL,
            function TEXT NOT NULL,
            name TEXT,
            output_col TEXT,
            var0 TEXT,
            var1 TEXT,
            var2 TEXT,
            var3 TEXT,
            var4 TEXT,
            var5 TEXT,
            var6 TEXT
        );
        """
    )

    # Bảng DASHBOARD_ROWS: mỗi row Dashboard = 1 job
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS dashboard_rows (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT NOT NULL,
            row_index INTEGER NOT NULL,
            status TEXT NOT NULL,
            data_json TEXT NOT NULL  -- JSON chứa các cột còn lại
        );
        """
    )

    # Bảng LOGS
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT NOT NULL,
            job_id INTEGER,
            level TEXT,
            message TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        """
    )

    conn.commit()
    return conn
