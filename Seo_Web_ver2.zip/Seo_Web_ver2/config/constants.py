# config/constants.py
"""
Các hằng số "luật hệ thống" – bám theo docs Tool Auto SEO.
"""

# Trạng thái Dashboard
STATUS_START = "start"
STATUS_PENDING = "pending"
STATUS_DONE = "done"

# Var0
VAR0_SINGLE = 1
VAR0_MULTI = 0

# Mode cho extract_object
MODE_SINGLE = "single"
MODE_MULTI = "multi"
MODE_EXPLODE = "explode"
