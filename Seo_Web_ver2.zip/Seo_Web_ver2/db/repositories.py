# db/repositories.py
"""
Các hàm CRUD nền tảng cho Big DB (flow, dashboard, log).

Backend_1, Backend_2, Backend_3 chỉ gọi qua layer này
→ không làm việc trực tiếp với sqlite3 cursor.
"""

import json
from datetime import datetime
from typing import Iterable, List, Optional

import sqlite3

from db.models import FlowStep, DashboardRow, Job, LogRecord
from config.constants import STATUS_START


# ==========================
# FLOW_STEPS
# ==========================

def insert_flow_steps(conn: sqlite3.Connection, steps: Iterable[FlowStep]) -> None:
    sql = """
        INSERT INTO flow_steps (
            session_id, step, function, name, output_col,
            var0, var1, var2, var3, var4, var5, var6
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """
    rows = [
        (
            s.session_id,
            s.step,
            s.function,
            s.name,
            s.output_col,
            s.var0,
            s.var1,
            s.var2,
            s.var3,
            s.var4,
            s.var5,
            s.var6,
        )
        for s in steps
    ]
    conn.executemany(sql, rows)
    conn.commit()


def get_flow_steps(conn: sqlite3.Connection, session_id: str) -> List[FlowStep]:
    sql = """
        SELECT *
        FROM flow_steps
        WHERE session_id = ?
        ORDER BY step ASC, id ASC
    """
    cur = conn.execute(sql, (session_id,))
    result: List[FlowStep] = []
    for row in cur.fetchall():
        result.append(
            FlowStep(
                id=row["id"],
                session_id=row["session_id"],
                step=row["step"],
                function=row["function"],
                name=row["name"] or "",
                output_col=row["output_col"] or "",
                var0=row["var0"] or "",
                var1=row["var1"] or "",
                var2=row["var2"] or "",
                var3=row["var3"] or "",
                var4=row["var4"] or "",
                var5=row["var5"] or "",
                var6=row["var6"] or "",
            )
        )
    return result


# ==========================
# DASHBOARD_ROWS / JOBS
# ==========================

def insert_dashboard_rows(
    conn: sqlite3.Connection, rows: Iterable[DashboardRow]
) -> None:
    sql = """
        INSERT INTO dashboard_rows (
            session_id, row_index, status, data_json
        )
        VALUES (?, ?, ?, ?)
    """
    values = [
        (
            r.session_id,
            r.row_index,
            r.status,
            json.dumps(r.data, ensure_ascii=False),
        )
        for r in rows
    ]
    conn.executemany(sql, values)
    conn.commit()


def get_dashboard_rows_by_status(
    conn: sqlite3.Connection,
    session_id: str,
    status: str = STATUS_START,
) -> List[DashboardRow]:
    sql = """
        SELECT *
        FROM dashboard_rows
        WHERE session_id = ? AND status = ?
        ORDER BY row_index ASC
    """
    cur = conn.execute(sql, (session_id, status))
    result: List[DashboardRow] = []
    for row in cur.fetchall():
        result.append(
            DashboardRow(
                id=row["id"],
                session_id=row["session_id"],
                row_index=row["row_index"],
                status=row["status"],
                data=json.loads(row["data_json"] or "{}"),
            )
        )
    return result


def dashboard_row_to_job(row: DashboardRow) -> Job:
    """Helper: convert DashboardRow → Job runtime."""
    if row.id is None:
        raise ValueError("DashboardRow must have id to convert to Job.")
    return Job(
        id=row.id,
        session_id=row.session_id,
        row_index=row.row_index,
        status=row.status,
        data=row.data,
    )


def update_dashboard_status(
    conn: sqlite3.Connection, row_id: int, new_status: str
) -> None:
    sql = "UPDATE dashboard_rows SET status = ? WHERE id = ?"
    conn.execute(sql, (new_status, row_id))
    conn.commit()


# ==========================
# LOGS
# ==========================

def insert_log(
    conn: sqlite3.Connection,
    session_id: str,
    message: str,
    level: str = "INFO",
    job_id: Optional[int] = None,
) -> None:
    sql = """
        INSERT INTO logs (session_id, job_id, level, message, created_at)
        VALUES (?, ?, ?, ?, ?)
    """
    created_at = datetime.utcnow().isoformat()
    conn.execute(sql, (session_id, job_id, level, message, created_at))
    conn.commit()


def get_logs_by_session(
    conn: sqlite3.Connection, session_id: str
) -> List[LogRecord]:
    sql = """
        SELECT *
        FROM logs
        WHERE session_id = ?
        ORDER BY id ASC
    """
    cur = conn.execute(sql, (session_id,))
    result: List[LogRecord] = []
    for row in cur.fetchall():
        result.append(
            LogRecord(
                id=row["id"],
                session_id=row["session_id"],
                job_id=row["job_id"],
                level=row["level"] or "INFO",
                message=row["message"],
                created_at=row["created_at"],
            )
        )
    return result
