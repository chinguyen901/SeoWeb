# actions/prompt_image.py

import base64
import json
import os
from pathlib import Path
from typing import Any, Dict, Callable, Optional, List

import requests


def _noop_log(msg: str) -> None:
    pass


# ============================================
# HELPERS
# ============================================

def _normalize_config(config_raw: Any) -> Dict[str, Any]:
    """
    Chuẩn hoá var4 cho đúng chuẩn Tool Auto SEO:
      {
        "api_key": "...",
        "endpoint": "...",
        "model": "...",
        "image_format": "png"
      }
    """
    if isinstance(config_raw, dict):
        return config_raw

    if isinstance(config_raw, str):
        try:
            return json.loads(config_raw)
        except:
            return {}

    return {}


def _ensure_output_path(path_local: str) -> Path:
    """
    path_local có thể là:
      - 1 file cụ thể:  D:/img/banner.png
      - hoặc 1 folder:  D:/img/banner_folder

    Tự động tạo folder nếu cần.
    """
    p = Path(path_local).expanduser()
    if p.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp"}:
        p.parent.mkdir(parents=True, exist_ok=True)
    else:
        p.mkdir(parents=True, exist_ok=True)
    return p


def _save_image(img_bytes: bytes, base_path: Path, index: int, ext: str) -> str:
    """
    Lưu ảnh ra file:

    - Nếu base_path là file → dùng file đó cho index=1, và file_index.png cho index>1
    - Nếu base_path là folder → tạo img_1.png, img_2.png...
    """
    if not ext.startswith("."):
        ext = "." + ext

    # base_path là 1 file
    if base_path.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp"}:
        if index == 1:
            out = base_path
        else:
            out = base_path.with_name(f"{base_path.stem}_{index}{base_path.suffix}")
    else:
        # base_path là folder
        out = base_path / f"img_{index}{ext}"

    out.write_bytes(img_bytes)
    return str(out.resolve())


# ============================================
# ACTION
# ============================================

def prompt_image(
    var0: Any,   # const 0/1 (hiện chưa dùng)
    var1: Any,   # main_message → prompt tạo ảnh
    var2: Any,   # size → ví dụ "1024x1024"
    var3: Any,   # path_local → nơi lưu ảnh
    var4: Any,   # config_json_api (CHỈ 4 field chuẩn)
    log_callback: Optional[Callable[[str], None]] = None,
) -> List[str]:

    log = log_callback or _noop_log

    # -------------------------
    # 1. Đọc & chuẩn hoá CONFIG
    # -------------------------
    cfg = _normalize_config(var4)

    api_key = cfg.get("api_key", "")
    endpoint = cfg.get("endpoint", "")
    model = cfg.get("model", "")
    image_format = cfg.get("image_format", "png").lower()

    if not endpoint:
        log("[prompt_image] ❌ Thiếu endpoint trong var4.")
        return []

    if not model:
        log("[prompt_image] ❌ Thiếu model trong var4.")
        return []

    if image_format not in {"png", "jpg", "jpeg", "webp"}:
        log(f"[prompt_image] ⚠ image_format '{image_format}' không hợp lệ, auto dùng 'png'.")
        image_format = "png"

    # -------------------------
    # 2. Chuẩn hoá INPUT
    # -------------------------
    prompt = "" if var1 is None else str(var1).strip()
    if not prompt:
        log("[prompt_image] ❌ Var1 prompt rỗng.")
        return []

    size = str(var2).strip() if var2 else "1024x1024"
    path_local = str(var3).strip() if var3 else "./generated_images"

    base_path = _ensure_output_path(path_local)

    # -------------------------
    # 3. Build request payload
    # -------------------------
    payload: Dict[str, Any] = {
        "model": model,
        "prompt": prompt,
        "size": size,
        "response_format": "b64_json",
        "n": 1   # tạo 1 ảnh duy nhất theo đặc tả Tool Auto SEO
    }

    headers = {
        "Content-Type": "application/json",
    }
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    log(f"[prompt_image] Gửi request → {endpoint} | model={model} | size={size}")

    # -------------------------
    # 4. Gọi API
    # -------------------------
    try:
        resp = requests.post(endpoint, headers=headers, json=payload, timeout=120)
    except Exception as e:
        log(f"[prompt_image] ❌ HTTP error: {e}")
        return []

    log(f"[prompt_image] HTTP status={resp.status_code}")

    if resp.status_code not in range(200, 300):
        body = resp.text[:500]
        log(f"[prompt_image] ❌ Request thất bại: {body}")
        return []

    # -------------------------
    # 5. Parse JSON + trích ảnh
    # -------------------------
    try:
        data = resp.json()
    except:
        log("[prompt_image] ❌ Response không phải JSON hợp lệ.")
        return []

    img_list = data.get("data", [])
    if not img_list:
        log("[prompt_image] ❌ Không có data ảnh trong response.")
        return []

    saved_paths: List[str] = []

    # OpenAI image API chuẩn: data[i].b64_json
    for idx, item in enumerate(img_list, start=1):
        b64_str = item.get("b64_json")
        if not b64_str:
            log("[prompt_image] ⚠ Không tìm thấy b64_json trong 1 item, bỏ qua.")
            continue

        try:
            img_bytes = base64.b64decode(b64_str)
        except:
            log("[prompt_image] ❌ Lỗi decode base64.")
            continue

        out_path = _save_image(img_bytes, base_path, idx, image_format)
        log(f"[prompt_image] ✅ Lưu ảnh #{idx}: {out_path}")
        saved_paths.append(out_path)

    return saved_paths
