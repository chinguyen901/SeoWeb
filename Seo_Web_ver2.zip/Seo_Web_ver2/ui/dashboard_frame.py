# ui/dashboard_frame.py
from pathlib import Path
from typing import Optional

import threading
from tkinter import filedialog

import customtkinter as ctk
from infrastructure.logger import Logger, LoggerConfig

from backend.backend_1_excel_import import init_bigdata, export_excel_to_db_on_start
from backend.backend_2_prepare_jobs import prepare_multithread_data
from backend.backend_3_worker_pool import start_jobs_multithread
from config.settings import DEFAULT_DB_FOLDER, MAX_THREAD_DEFAULT


class DashboardFrame(ctk.CTkFrame):
    def __init__(self, master, username: str):
        super().__init__(master)
        self.username = username

        # Biến lưu đường dẫn
        self.folder_var = ctk.StringVar(value=DEFAULT_DB_FOLDER)
        self.excel_var = ctk.StringVar(value="")
        self.thread_var = ctk.StringVar(value=str(MAX_THREAD_DEFAULT))

        # State backend
        self.db_excel_path: Optional[Path] = None
        self.threads: list[threading.Thread] = []
        self.stop_event: Optional[threading.Event] = None
        self._start_thread: Optional[threading.Thread] = None

        # State log (lưu full nội dung từng dòng)
        self.full_logs: list[str] = []

        # Khởi tạo Bigdata DB (nếu cần)
        init_bigdata()

        # Xây UI (tạo self.log_text trước khi dùng logger)
        self.build_ui()

        # Buffer log để flush theo batch
        self._pending_logs: list[str] = []
        self._flush_scheduled: bool = False

        # Khởi tạo Logger (ghi ra UI + console)
        # ⚠ dùng append_log (thread-safe), KHÔNG gọi trực tiếp _append_log_ui
        self.logger = Logger(
            ui_log_callback=self.append_log,
            config=LoggerConfig(enable_console=True),
        )

    # ======================================
    # UI
    # ======================================
    def build_ui(self):
        self.configure(corner_radius=0)

        title = ctk.CTkLabel(
            self,
            text=f"SEO WEB – Dashboard (User: {self.username})",
            font=("Arial", 20, "bold"),
        )
        title.pack(pady=15)

        # --- chọn folder DB ---
        folder_frame = ctk.CTkFrame(self)
        folder_frame.pack(fill="x", padx=15, pady=5)

        ctk.CTkLabel(folder_frame, text="Folder DB:").pack(side="left", padx=(5, 10))

        folder_entry = ctk.CTkEntry(
            folder_frame, textvariable=self.folder_var, width=260
        )
        folder_entry.pack(side="left", padx=(0, 10))

        btn_folder = ctk.CTkButton(
            folder_frame, text="Chọn Folder", width=100, command=self.choose_folder
        )
        btn_folder.pack(side="left")

        # --- chọn file Excel ---
        excel_frame = ctk.CTkFrame(self)
        excel_frame.pack(fill="x", padx=15, pady=5)

        ctk.CTkLabel(excel_frame, text="File Excel:").pack(side="left", padx=(5, 10))

        excel_entry = ctk.CTkEntry(
            excel_frame, textvariable=self.excel_var, width=260
        )
        excel_entry.pack(side="left", padx=(0, 10))

        btn_excel = ctk.CTkButton(
            excel_frame, text="Chọn Excel", width=100, command=self.choose_excel
        )
        btn_excel.pack(side="left")

        # --- số thread ---
        thread_frame = ctk.CTkFrame(self)
        thread_frame.pack(fill="x", padx=15, pady=5)

        ctk.CTkLabel(thread_frame, text="Số thread:").pack(
            side="left", padx=(5, 10)
        )

        thread_entry = ctk.CTkEntry(
            thread_frame, textvariable=self.thread_var, width=80
        )
        thread_entry.pack(side="left")

        # --- các nút điều khiển ---
        button_frame = ctk.CTkFrame(self, fg_color="transparent")
        button_frame.pack(fill="x", padx=15, pady=10)

        btn_start = ctk.CTkButton(
            button_frame, text="START", width=100, command=self.start
        )
        btn_start.pack(side="left", padx=(0, 10))

        btn_stop = ctk.CTkButton(
            button_frame, text="STOP", width=100, command=self.stop
        )
        btn_stop.pack(side="left", padx=(0, 10))

        btn_clear = ctk.CTkButton(
            button_frame, text="CLEAR LOG", width=100, command=self.clear_log
        )
        btn_clear.pack(side="left", padx=(0, 10))

        # --- khung LOG ---
        log_label = ctk.CTkLabel(self, text="LOG", font=("Arial", 14, "bold"))
        log_label.pack(anchor="w", padx=15)

        self.log_text = ctk.CTkTextbox(self, height=260)
        self.log_text.pack(fill="both", expand=True, padx=15, pady=(5, 15))
        self.log_text.configure(state="disabled")

    # ======================================
    # CHỌN ĐƯỜNG DẪN
    # ======================================
    def choose_folder(self):
        folder = filedialog.askdirectory()
        if folder:
            self.folder_var.set(folder)

    def choose_excel(self):
        filetypes = [("Excel Files", "*.xlsx *.xls"), ("All files", "*.*")]
        file_path = filedialog.askopenfilename(filetypes=filetypes)
        if file_path:
            self.excel_var.set(file_path)

    # ======================================
    # START – 1 THREAD LOGIC RIÊNG
    # ======================================
    def start(self):
        """Khởi chạy TOOL trên một thread logic riêng."""
        if self._start_thread is not None and self._start_thread.is_alive():
            self.logger.warning("⚠ Start đang chạy, vui lòng đợi hoàn tất.")
            return

        self._start_thread = threading.Thread(
            target=self._start_worker,
            daemon=True,
        )
        self._start_thread.start()

    def _start_worker(self):
        """
        Logic chính khi bấm START (chạy trên thread riêng).
        1) Xuất DB SQLite từ Excel (backend_1)
        2) Load Flow + Dashboard (backend_2)
        3) Multithread thực thi job (backend_3)
        """
        try:
            excel_path = self.excel_var.get().strip()
            folder_path = self.folder_var.get().strip()

            if not excel_path:
                self.logger.error("❌ Chưa chọn file Excel!")
                return

            if not folder_path:
                self.logger.error("❌ Chưa chọn Folder DB!")
                return

            # 1) EXPORT EXCEL → SQLITE + lưu session vào bigdata
            self.logger.info("[BACKEND_1] Bắt đầu export Excel → DB ...")
            self.db_excel_path = export_excel_to_db_on_start(
                excel_path=excel_path,
                folder_path=folder_path,
            )
            self.logger.info(
                f"[BACKEND_1] ✅ Đã xuất DB SQL tại: {self.db_excel_path}"
            )

            # 2) LOAD FLOW + DASHBOARD
            self.logger.info("[BACKEND_2] Đang load FLOW & DASHBOARD ...")

            flow_steps, jobs = prepare_multithread_data(
                str(self.db_excel_path),
                log_callback=self.logger.info,
            )

            if not jobs:
                self.logger.warning("[BACKEND_2] ❌ Dashboard không có job nào.")
                return

            self.logger.info(
                f"[BACKEND_2] ✅ HOÀN THÀNH. Flow: {len(flow_steps)}, Jobs: {len(jobs)}"
            )

            # 3) BACKEND_3 – MULTITHREAD JOBS
            self.stop_event = threading.Event()

            try:
                max_threads = int(self.thread_var.get())
            except ValueError:
                max_threads = MAX_THREAD_DEFAULT
                self.logger.warning(
                    f"⚠ Số thread không hợp lệ, dùng mặc định = {MAX_THREAD_DEFAULT}."
                )

            self.logger.info(
                f"[BACKEND_3] Bắt đầu chạy jobs với tối đa {max_threads} thread ..."
            )

            threads, self.stop_event = start_jobs_multithread(
                jobs=jobs,
                flow_steps=flow_steps,
                max_threads=max_threads,
                db_path=str(self.db_excel_path),
                log_callback=self.logger.info,
                stop_event=self.stop_event,
            )

            self.threads = threads
            self.logger.info(
                f"[BACKEND_3] ✅ Tổng số thread đã tạo = {len(threads)}."
            )

        except Exception as e:
            self.logger.error(f"❌ Lỗi khi Start: {e}")

    # ======================================
    # STOP – 1 THREAD LOGIC RIÊNG
    # ======================================
    def stop(self):
        """Gửi tín hiệu STOP trên một thread logic riêng."""
        t = threading.Thread(target=self._stop_worker, daemon=True)
        t.start()

    def _stop_worker(self):
        if self.stop_event is not None:
            self.stop_event.set()
            self.logger.info("🛑 Đã gửi tín hiệu STOP cho toàn bộ thread.")
        else:
            self.logger.warning("⚠ Chưa có thread nào đang chạy để STOP.")

    # ======================================
    # CLEAR LOG – AN TOÀN TRÊN UI THREAD
    # ======================================
    def clear_log(self):
        """Xóa log một cách an toàn trên UI thread."""
        self.after(0, self._clear_log_ui)

    def _clear_log_ui(self):
        self.log_text.configure(state="normal")
        self.log_text.delete("1.0", "end")
        self.log_text.configure(state="disabled")
        self.full_logs.clear()

    # ======================================
    # LOG UI – “SINK” CHO LOGGER
    # ======================================
    def _append_log_ui(self, text: str):
        """
        Ghi log vào Textbox.
        - Lưu full text vào self.full_logs
        - Rút ngắn nếu quá dài: hiển thị dạng "xxx [...]"
        - Bind click vào [...] để expand full dòng.
        (Chỉ gọi trên main thread.)
        """
        MAX_CHARS = 60

        # Lưu FULL text
        line_index = len(self.full_logs)
        self.full_logs.append(text)

        # Quyết định text hiển thị
        if len(text) > MAX_CHARS:
            display_text = text[:MAX_CHARS] + " [...]"
            truncated = True
        else:
            display_text = text
            truncated = False

        self.log_text.configure(state="normal")

        # Vị trí bắt đầu của dòng mới (ngay cuối hiện tại)
        line_start = self.log_text.index("end-1c")
        self.log_text.insert("end", display_text)
        line_end = self.log_text.index("end-1c")

        # Gán tag cho cả dòng
        line_tag = f"logline_{line_index}"
        self.log_text.tag_add(line_tag, line_start, line_end)

        # Nếu có rút gọn → tag clickable cho "[...]"
        if truncated:
            ellipsis = "[...]"
            expand_tag = f"expand_{line_index}"

            ellipsis_start = f"{line_start}+{len(display_text) - len(ellipsis)}c"
            ellipsis_end = f"{line_start}+{len(display_text)}c"

            self.log_text.tag_add(expand_tag, ellipsis_start, ellipsis_end)
            self.log_text.tag_config(expand_tag, foreground="#33AFFF", underline=True)
            self.log_text.tag_bind(
                expand_tag,
                "<Button-1>",
                lambda e, i=line_index: self.expand_log(i),
            )

        # 🔑 Luôn thêm newline sau mỗi log
        self.log_text.insert("end", "\n")

        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def expand_log(self, line_index: int):
        """Expand 1 dòng log đã bị rút gọn."""
        if line_index < 0 or line_index >= len(self.full_logs):
            return

        full_text = self.full_logs[line_index]
        line_tag = f"logline_{line_index}"
        expand_tag = f"expand_{line_index}"

        ranges = self.log_text.tag_ranges(line_tag)
        if not ranges or len(ranges) < 2:
            return

        start, end = ranges[0], ranges[1]

        self.log_text.configure(state="normal")
        self.log_text.delete(start, end)
        self.log_text.insert(start, full_text)

        new_end = f"{start}+{len(full_text)}c"
        self.log_text.tag_add(line_tag, start, new_end)
        self.log_text.tag_delete(expand_tag)
        self.log_text.configure(state="disabled")

    # ======================================
    # API CŨ – VẪN HỖ TRỢ
    # ======================================
    def append_log(self, text: str):
        """
        API cũ – thread-safe.
        Bây giờ: không gọi _append_log_ui trực tiếp nữa,
        mà push vào buffer rồi flush theo batch.
        """
        # Được gọi từ nhiều thread khác nhau
        self._pending_logs.append(text)

        # Chỉ schedule 1 lần, sau đó _flush_log_ui() sẽ reset flag
        if not self._flush_scheduled:
            self._flush_scheduled = True
            self.after(30, self._flush_log_ui)   # 30ms/lần, tuỳ chỉnh

    def _flush_log_ui(self):
        """
        Chạy trên UI thread.
        Lấy toàn bộ log pending ra và vẽ vào Textbox một lượt.
        """
        self._flush_scheduled = False

        if not self._pending_logs:
            return

        # copy & clear buffer
        pending = self._pending_logs[:]
        self._pending_logs.clear()

        for line in pending:
            self._append_log_ui(line)

