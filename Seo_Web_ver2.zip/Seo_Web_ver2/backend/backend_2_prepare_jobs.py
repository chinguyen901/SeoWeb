# backend/backend_2_prepare_jobs.py
# =========================================
# BACKEND 2 – LOAD DATA FROM SQLITE → FLOW_STEPS + JOBS
# =========================================

from typing import Callable, Optional

from backend.flow_engine.step_template_loader import (
    load_flow_steps_from_db,
    load_jobs_from_db,
)


def _log(message: str, log_callback: Optional[Callable[[str], None]] = None):
    if log_callback:
        log_callback(f"[BACKEND_2] {message}")
    else:
        print(f"[BACKEND_2] {message}")


def prepare_multithread_data(db_path: str, log_callback=None):
    """
    - Đọc bảng Flow & Dashboard trong db_path
    - Trả về: (flow_steps, jobs) để Backend_3 xử lý
    """
    try:
        flow_steps = load_flow_steps_from_db(db_path, log_callback)
        jobs = load_jobs_from_db(db_path, log_callback)

        _log(
            f"[MULTITHREAD] PREPARE OK | DB={db_path} | FlowSteps={len(flow_steps)} | Jobs={len(jobs)}",
            log_callback,
        )

        return flow_steps, jobs

    except Exception as e:
        _log(f"[MULTITHREAD][EXCEPTION] {e} | DB={db_path}", log_callback)
        raise
