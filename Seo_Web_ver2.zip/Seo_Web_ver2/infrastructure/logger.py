# infrastructure/logger.py
"""
Logger chung:
- Ghi log ra UI (append_log)
- Ghi log ra console
- Tuỳ chọn ghi log vào DB thông qua 1 callback db_writer.
"""

from dataclasses import dataclass
from datetime import datetime
from typing import Callable, Optional


LogCallback = Callable[[str], None]
DBWriter = Callable[[str, str, str, Optional[int]], None]
# DBWriter(session_id, level, message, job_id)


@dataclass
class LoggerConfig:
    session_id: Optional[str] = None
    enable_console: bool = True


class Logger:
    def __init__(
        self,
        ui_log_callback: Optional[LogCallback] = None,
        db_writer: Optional[DBWriter] = None,
        config: Optional[LoggerConfig] = None,
    ):
        """
        ui_log_callback: hàm append_log(text) từ UI (DashboardFrame)
        db_writer: hàm ghi DB: db_writer(session_id, level, message, job_id)
        config: session_id, enable_console,...
        """
        self.ui_log_callback = ui_log_callback
        self.db_writer = db_writer
        self.config = config or LoggerConfig()

    # ----------------------------------------------
    # HÀM NỘI BỘ
    # ----------------------------------------------
    def _format(self, level: str, message: str) -> str:
        ts = datetime.now().strftime("%H:%M:%S")
        return f"[{ts}] [{level}] {message}"

    def _write_ui(self, text: str):
        if self.ui_log_callback:
            self.ui_log_callback(text)

    def _write_console(self, text: str):
        if self.config.enable_console:
            print(text)

    def _write_db(self, level: str, message: str, job_id: Optional[int]):
        if self.db_writer and self.config.session_id:
            # session_id được set từ bên ngoài (Backend_1 tạo session)
            self.db_writer(self.config.session_id, level, message, job_id)

    # ----------------------------------------------
    # PUBLIC API
    # ----------------------------------------------
    def log(self, level: str, message: str, job_id: Optional[int] = None):
        text = self._format(level, message)
        # self._write_console(text)
        self._write_ui(text)
        self._write_db(level, message, job_id)

    def info(self, message: str, job_id: Optional[int] = None):
        self.log("INFO", message, job_id)

    def warning(self, message: str, job_id: Optional[int] = None):
        self.log("WARN", message, job_id)

    def error(self, message: str, job_id: Optional[int] = None):
        self.log("ERROR", message, job_id)
