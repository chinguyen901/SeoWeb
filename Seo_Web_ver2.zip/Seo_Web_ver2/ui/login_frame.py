# ui/login_frame.py
import customtkinter as ctk
import requests
import json
import os
import threading
from CTkMessagebox import CTkMessagebox

from config.settings import (
    BACKEND_LOGIN_URL,
    IP_API_URL,
    LOGIN_CONFIG_FILE,
)


class LoginFrame(ctk.CTkFrame):
    def __init__(self, master, switch_to_dashboard):
        super().__init__(master)
        self.switch_to_dashboard = switch_to_dashboard

        # Biến lưu thông tin
        self.username_var = ctk.StringVar()
        self.password_var = ctk.StringVar()
        self.remember_var = ctk.BooleanVar(value=False)
        self.ip_text = ctk.StringVar(value="My IP: Chưa kiểm")

        # UI
        self.build_ui()

        # Load config nếu có
        self.load()

        # Auto check IP
        self.after(100, self.check_ip)

    # =============================
    # UI
    # =============================
    def build_ui(self):
        self.configure(corner_radius=10)

        # ==== TITLE ====
        title = ctk.CTkLabel(self, text="ĐĂNG NHẬP", font=("Arial", 22, "bold"))
        title.pack(pady=25)

        # ==== USER ====
        entry_user = ctk.CTkEntry(
            self,
            placeholder_text="Username",
            width=300,
            height=36,
            textvariable=self.username_var,
        )
        entry_user.pack(pady=15)

        # ==== PASSWORD ====
        password_frame = ctk.CTkFrame(self, fg_color="transparent")
        password_frame.pack(pady=15)

        entry_pass = ctk.CTkEntry(
            password_frame,
            placeholder_text="Password",
            width=260,
            height=36,
            show="*",
            textvariable=self.password_var,
        )
        entry_pass.pack(side="left", padx=(0, 5))

        btn_show = ctk.CTkButton(
            password_frame,
            text="👁",
            width=35,
            command=lambda: self.toggle_password(entry_pass),
        )
        btn_show.pack(side="left")

        # ==== REMEMBER ME ====
        remember_chk = ctk.CTkCheckBox(
            self, text="Ghi nhớ tài khoản", variable=self.remember_var
        )
        remember_chk.pack(pady=(5, 10))

        # ==== MY IP ====
        ip_frame = ctk.CTkFrame(self, fg_color="transparent")
        ip_frame.pack(pady=15)

        ip_label = ctk.CTkLabel(ip_frame, textvariable=self.ip_text)
        ip_label.pack(side="left", padx=(0, 10))

        btn_ip = ctk.CTkButton(ip_frame, text="Check My IP", command=self.check_ip)
        btn_ip.pack(side="left")

        # ==== BUTTON LOGIN ====
        btn_login = ctk.CTkButton(
            self, text="ĐĂNG NHẬP", width=260, height=36, command=self.login
        )
        btn_login.pack(pady=20)

    # =============================
    # HỖ TRỢ
    # =============================
    def toggle_password(self, entry):
        current = entry.cget("show")
        entry.configure(show="" if current == "*" else "*")

    def load(self):
        """Load user/pass/ip từ file JSON nếu có."""
        if not os.path.exists(LOGIN_CONFIG_FILE):
            return

        try:
            with open(LOGIN_CONFIG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)

            self.username_var.set(data.get("username", ""))
            self.password_var.set(data.get("password", ""))
            ip = data.get("ip", "")
            if ip:
                self.ip_text.set(f"My IP : {ip}")
            self.remember_var.set(bool(data.get("remember", False)))
        except Exception:
            # Không cần báo lỗi, chỉ bỏ qua
            pass

    def save(self, username, password, ip):
        """Lưu user/pass/ip vào JSON."""
        try:
            data = {
                "username": username,
                "password": password,
                "ip": ip,
                "remember": bool(self.remember_var.get()),
            }
            with open(LOGIN_CONFIG_FILE, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def clear(self):
        """Xóa thông tin đã lưu."""
        self.username_var.set("")
        self.password_var.set("")
        self.remember_var.set(False)
        if os.path.exists(LOGIN_CONFIG_FILE):
            try:
                os.remove(LOGIN_CONFIG_FILE)
            except Exception:
                pass

    # =============================
    # CHECK IP
    # =============================
    def check_ip(self):
        """Lấy IP public và hiển thị."""

        def _worker():
            try:
                resp = requests.get(IP_API_URL, timeout=5)
                data = resp.json()
                ip = data.get("ip", "")
                if ip:
                    self.after(0, lambda: self.ip_text.set(f"My IP: {ip}"))
                else:
                    self.after(0, lambda: self.ip_text.set("My IP: Không lấy được"))
            except Exception:
                self.after(0, lambda: self.ip_text.set("My IP: Không lấy được"))

        threading.Thread(target=_worker, daemon=True).start()

    # =============================
    # LOGIN – CHẠY TRÊN 1 THREAD RIÊNG
    # =============================
    def login(self):
        username = self.username_var.get().strip()
        password = self.password_var.get().strip()
        ip = self.ip_text.get().replace("My IP:", "").strip()

        if not username or not password:
            CTkMessagebox(
                title="Lỗi",
                message="Vui lòng nhập user và pass.",
                icon="cancel",
            )
            return

        if "Chưa kiểm" in ip or "Không lấy được" in ip:
            CTkMessagebox(
                title="Lỗi",
                message="Vui lòng Check My IP.",
                icon="warning",
            )
            return

        # 🔹 CHẠY LOGIN TRÊN THREAD RIÊNG (KHÔNG KHÓA UI)
        t = threading.Thread(
            target=self._login_worker, args=(username, password, ip), daemon=True
        )
        t.start()

    def _login_worker(self, username, password, ip):
        """Worker chạy trên thread phụ, gọi API backend."""
        try:
            resp = requests.post(
                BACKEND_LOGIN_URL,
                json={"username": username, "password": password, "ip": ip},
                timeout=10,
            )
            data = resp.json()
        except Exception as e:
            self.after(
                0,
                lambda: CTkMessagebox(
                    title="Lỗi",
                    message=str(e),
                    icon="cancel",
                ),
            )
            return

        # Xử lý kết quả trên UI thread
        if data.get("success"):
            def _on_success():
                if self.remember_var.get():
                    self.save(username, password, ip)
                else:
                    self.clear()
                self.switch_to_dashboard(username)

            self.after(0, _on_success)
        else:
            msg = data.get("message") or "Sai thông tin đăng nhập."
            self.after(
                0,
                lambda: CTkMessagebox(
                    title="Sai thông tin",
                    message=msg,
                    icon="cancel",
                ),
            )
