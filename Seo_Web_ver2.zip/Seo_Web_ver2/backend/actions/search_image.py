# actions/search_image.py

import json
import os
from pathlib import Path
from typing import Any, Dict, Optional, Callable, List
from urllib.parse import urlparse

import requests


def _noop_log(msg: str) -> None:
    """Default log callback (no-op)."""
    pass


# ======================================================
# HELPERS
# ======================================================

def _normalize_config(config_raw: Any) -> Dict[str, Any]:
    """
    Chuẩn hoá var4 (config_json_api) về dict:

    Cho phép:
      - dict: dùng luôn
      - str  : cố parse JSON
      - None / lỗi: trả dict rỗng
    """
    if isinstance(config_raw, dict):
        return dict(config_raw)

    if isinstance(config_raw, str):
        s = config_raw.strip()
        if not s:
            return {}
        try:
            obj = json.loads(s)
            if isinstance(obj, dict):
                return obj
        except Exception:
            return {}

    return {}


def _normalize_search_cfg(search_cfg_raw: Any) -> Dict[str, Any]:
    """
    Chuẩn hoá var2 (config_search) về dict:

    Cho phép:
      - dict
      - str JSON
      - None → {}
    """
    if isinstance(search_cfg_raw, dict):
        return dict(search_cfg_raw)

    if isinstance(search_cfg_raw, str):
        s = search_cfg_raw.strip()
        if not s:
            return {}
        try:
            obj = json.loads(s)
            if isinstance(obj, dict):
                return obj
        except Exception:
            return {}

    return {}


def _ensure_dir_for_path(path_local: str) -> Path:
    """
    Đảm bảo thư mục tồn tại cho path_local.

    - Nếu path_local là file (có suffix ảnh) → tạo thư mục cha.
    - Nếu là folder                           → tạo folder đó.

    Trả về:
      - Path object đã chuẩn hoá.
    """
    p = Path(path_local).expanduser()

    if p.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp"}:
        p.parent.mkdir(parents=True, exist_ok=True)
    else:
        p.mkdir(parents=True, exist_ok=True)

    return p


def _save_image_bytes(
    img_bytes: bytes,
    base_path: Path,
    index: int,
    default_ext: str = ".jpg",
) -> str:
    """
    Lưu bytes ảnh ra file.

    - base_path:
        - Nếu là file (có suffix) → ghi trực tiếp (nếu index>1 thì thêm _{index}).
        - Nếu là folder          → tạo file img_{index}{ext} trong folder.

    - default_ext: dùng nếu base_path là folder và không có đuôi cụ thể.

    Trả về:
      - Đường dẫn tuyệt đối dạng string.
    """
    ext = default_ext.lower()
    if not ext.startswith("."):
        ext = "." + ext

    if base_path.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp"}:
        if index == 1:
            out_path = base_path
        else:
            stem = base_path.stem
            out_path = base_path.with_name(f"{stem}_{index}{base_path.suffix}")
    else:
        out_path = base_path / f"img_{index}{ext}"

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(img_bytes)

    return str(out_path.resolve())


def _extract_domain(url: str) -> str:
    """
    Lấy domain (hostname) từ URL.
    """
    try:
        parsed = urlparse(url)
        return parsed.hostname or ""
    except Exception:
        return ""


def _build_cse_params(
    keywords: str,
    search_cfg: Dict[str, Any],
    api_cfg: Dict[str, Any],
    log: Callable[[str], None],
) -> Dict[str, Any]:
    """
    Tạo query params cho Google Custom Search (Image Search).
    Dựa trên:
      - keywords
      - config_search (var2)
      - config_json_api (var4)

    Google CSE yêu cầu:
      - key: api_key
      - cx : search engine id (nếu bạn có)
      - q  : từ khoá
      - searchType=image
    """
    params: Dict[str, Any] = {}

    # key bắt buộc
    api_key = (api_cfg.get("api_key") or "").strip()
    if not api_key:
        log("[ACTION=search_image] ❌ Thiếu api_key trong config_json_api.")
    params["key"] = api_key

    # cx nếu có (không ghi trong spec nhưng Google CSE thường yêu cầu)
    cx = (api_cfg.get("cx") or "").strip()
    if not cx:
        log("[ACTION=search_image] ⚠ Chưa cấu hình 'cx' trong config_json_api. Hãy đảm bảo endpoint của bạn không yêu cầu cx.")
    else:
        params["cx"] = cx

    params["q"] = keywords
    params["searchType"] = "image"

    # location -> gl
    location = (search_cfg.get("location") or "").strip()
    if location and location.lower() != "any":
        params["gl"] = location.lower()

    # language -> hl
    language = (search_cfg.get("language") or "").strip()
    if language and language.lower() != "any":
        params["hl"] = language.lower()

    # time_range -> dateRestrict
    time_range = (search_cfg.get("time_range") or "").strip()
    if time_range:
        tr = time_range.lower()
        if tr in {"past_24_hours", "past_day", "last_24_hours"}:
            params["dateRestrict"] = "d1"
        elif tr in {"past_7_days", "past_week"}:
            params["dateRestrict"] = "w1"
        elif tr in {"past_month", "past_30_days"}:
            params["dateRestrict"] = "m1"
        # "any" → không set gì

    # size -> imgSize
    size = (search_cfg.get("size") or "").strip().lower()
    if size and size != "any":
        # Google CSE cho imgSize: icon, small, medium, large, xlarge, xxlarge, huge
        # map đơn giản:
        map_size = {
            "icon": "icon",
            "small": "small",
            "medium": "medium",
            "large": "large",
            "xlarge": "xlarge",
            "xxlarge": "xxlarge",
            "huge": "huge",
        }
        params["imgSize"] = map_size.get(size, "large")

    # color -> imgColorType
    color = (search_cfg.get("color") or "").strip().lower()
    if color and color != "any":
        # Google: color, gray, mono, transparent
        if color == "color":
            params["imgColorType"] = "color"
        elif color in {"black_and_white", "gray", "grey"}:
            params["imgColorType"] = "gray"
        elif color == "transparent":
            params["imgColorType"] = "transparent"

    # maxResults (số kết quả mỗi lần gọi) – Google giới hạn tối đa 10
    # max_results = api_cfg.get("max_results")
    # try:
    #     max_r = int(max_results) if max_results is not None else 5
    # except Exception:
    #     max_r = 5
    # params["num"] = max(1, min(max_r, 10))

    return params


# ======================================================
# ACTION CHÍNH
# ======================================================

def search_image(
    var0: Any,  # const 0/1 (tạm chưa dùng – để future multi prompt, paging...)
    var1: Any,  # keywords (từ khoá cần tìm kiếm)
    var2: Any,  # config_search (filter nâng cao: location, language, time_range, size, color)
    var3: Any,  # path_local (nơi lưu ảnh)
    var4: Any,  # config_json_api (api_key, endpoint, first_choice, black_list, ...)
    log_callback: Optional[Callable[[str], None]] = None,
) -> List[str]:
    """
    ACTION: search_image

        output = search_image(var0, var1, var2, var3, var4)

    Tham số:
      - var0: const 0 hoặc 1 (chưa dùng trong logic)
      - var1: keywords (string) → từ khoá tìm kiếm ảnh
      - var2: config_search (dict / str JSON), ví dụ:

            {
              "location": "vn",
              "language": "vi",
              "time_range": "past_7_days",
              "size": "large",
              "color": "color"
            }

        Các trường (có thể bỏ trống):
          location   : "vn", "us", ...
          language   : "vi", "en", ...
          time_range : "past_24_hours", "past_7_days", "past_week", "past_month", "any"
          size       : "large", "medium", "icon", "any"
          color      : "color", "black_and_white", "transparent", "any"

      - var3: path_local (string) → đường dẫn lưu ảnh sau khi tải về từ Google SERP Image.
               Có thể:
                 - folder: "D:/Images/search_results"
                 - file  : "D:/Images/keyword.png" (nếu tải nhiều ảnh sẽ thêm _2, _3,...)

      - var4: config_json_api (dict / str JSON), ví dụ:

            {
              "api_key": "your_google_api_key_here",
              "endpoint": "https://customsearch.googleapis.com/customsearch/v1",
              "cx": "your_search_engine_id",
              "first_choice": [
                "pinterest.com",
                "unsplash.com",
                "pixabay.com"
              ],
              "black_list": [
                "shutterstock.com",
                "istockphoto.com"
              ],
              "max_results": 5
            }

        Trường:
          api_key     : API key của Google Custom Search
          endpoint    : URL endpoint của Google CSE
          cx          : (tuỳ chọn nhưng thường bắt buộc) search engine id
          first_choice: list domain ưu tiên
          black_list  : list domain loại bỏ
          max_results : số ảnh tối đa muốn tải (1–10)

    Trả về:
      - List[str]: danh sách đường dẫn local tới các file ảnh đã lưu (có thể rỗng nếu lỗi).
    """
    log = log_callback or _noop_log

    # --------- Chuẩn hoá input ---------
    keywords = "" if var1 is None else str(var1).strip()
    if not keywords:
        log("[ACTION=search_image] ❌ keywords (var1) rỗng, không thể tìm kiếm.")
        return []

    search_cfg = _normalize_search_cfg(var2)
    api_cfg = _normalize_config(var4)

    endpoint = (api_cfg.get("endpoint") or "").strip()
    if not endpoint:
        log("[ACTION=search_image] ❌ Thiếu endpoint trong config_json_api (var4.endpoint).")
        return []

    path_local = "" if var3 is None else str(var3).strip()
    if not path_local:
        log("[ACTION=search_image] ⚠ path_local (var3) rỗng, auto dùng './search_images'.")
        path_local = "./search_images"

    base_path = _ensure_dir_for_path(path_local)

    # Domain filter
    first_choice = api_cfg.get("first_choice") or []
    if not isinstance(first_choice, list):
        first_choice = []
    first_choice = [str(d).strip().lower() for d in first_choice if str(d).strip()]

    black_list = api_cfg.get("black_list") or []
    if not isinstance(black_list, list):
        black_list = []
    black_list = [str(d).strip().lower() for d in black_list if str(d).strip()]

    # --------- Build query params ---------
    params = _build_cse_params(
        keywords=keywords,
        search_cfg=search_cfg,
        api_cfg=api_cfg,
        log=log,
    )

    # --------- Gọi Google CSE ---------
    try:
        resp = requests.get(
            endpoint,
            params=params,
            timeout=int(api_cfg.get("timeout", 60)),
        )
    except Exception as e:
        log(f"[ACTION=search_image] ❌ HTTP error: {e}")
        return []

    status = resp.status_code
    text_body = resp.text

    log(f"[ACTION=search_image] HTTP status={status}")

    if status < 200 or status >= 300:
        snippet = text_body[:500] if text_body else ""
        log(f"[ACTION=search_image] ❌ Request thất bại, body: {snippet}")
        return []

    # --------- Parse JSON & lấy danh sách ảnh ---------
    try:
        resp_json = resp.json()
    except Exception:
        log("[ACTION=search_image] ❌ Response không phải JSON hợp lệ.")
        return []

    items = resp_json.get("items")
    if not isinstance(items, list) or not items:
        log("[ACTION=search_image] ❌ Không tìm thấy kết quả ảnh nào (items rỗng).")
        return []

    log(f"[ACTION=search_image] Tìm thấy {len(items)} kết quả (items). Áp dụng bộ lọc domain...")

    # --------- Lọc domain + gom tất cả kết quả ---------
    all_items: List[Dict[str, Any]] = []

    for item in items:
        if not isinstance(item, dict):
            continue

        image_link = item.get("link")
        image_info = item.get("image")
        
        context_link = None
        if isinstance(image_info, dict):
            context_link = image_info.get("contextLink") or image_link
        else:
            context_link = image_link

        if not image_link:
            continue

        domain = _extract_domain(context_link or image_link).lower()
        if not domain:
            domain = _extract_domain(image_link).lower()

        # Loại bỏ domain nằm trong black_list
        if any(bad in domain for bad in black_list):
            log(f"[ACTION=search_image] Bỏ qua domain trong black_list: {domain}")
            continue

        all_items.append({
            "image_link": image_link,
            "context_link": context_link,
            "domain": domain
        })

    if not all_items:
        log("[ACTION=search_image] ❌ Không còn ảnh hợp lệ sau khi lọc black_list.")
        return []

    # --------- TẠO THỨ TỰ ƯU TIÊN THEO first_choice (1 → 2 → 3) ---------
    # Map domain → priority index
    priority_map = {domain: idx for idx, domain in enumerate(first_choice, start=1)}

    def get_priority(domain: str) -> int:
        """
        Trả về số ưu tiên:
            - pinterest.com → 1
            - unsplash.com → 2
            - pixabay.com → 3
            - domain khác → 999 (cuối)
        """
        for fc in first_choice:
            if fc in domain:
                return priority_map[fc]
        return 999

    # SẮP XẾP KẾT QUẢ THEO PRIORITY
    final_items = sorted(all_items, key=lambda item: get_priority(item["domain"]))

    log(f"[ACTION=search_image] Tổng {len(final_items)} kết quả sau khi áp dụng ưu tiên: {first_choice}")



    # Gộp: ưu tiên domain trong first_choice trước
    # final_items: List[Dict[str, Any]] = prioritized_items + normal_items

    if not final_items:
        log("[ACTION=search_image] ❌ Không còn ảnh nào sau khi áp dụng bộ lọc domain.")
        return []

    # --------- Tải ảnh & lưu local ---------
    saved_paths: List[str] = []
    max_save = len(final_items)

    for idx, entry in enumerate(final_items, start=1):
        image_link = entry["image_link"]
        domain = entry["domain"]

        log(f"[ACTION=search_image] ({idx}/{max_save}) Tải ảnh từ {image_link} (domain={domain})")
        try:
            r = requests.get(image_link, timeout=60)
            r.raise_for_status()
            img_bytes = r.content
        except Exception as e:
            log(f"[ACTION=search_image] ❌ Không tải được ảnh từ {image_link}: {e}")
            continue

        # Chọn đuôi file dựa theo content-type (nếu có)
        ext = ".jpg"
        content_type = r.headers.get("Content-Type", "")
        content_type = content_type.lower()
        if "png" in content_type:
            ext = ".png"
        elif "webp" in content_type:
            ext = ".webp"
        elif "jpeg" in content_type:
            ext = ".jpg"

        out_path = _save_image_bytes(
            img_bytes=img_bytes,
            base_path=base_path,  
            index=idx,
            default_ext=ext,
        )
        log(f"[ACTION=search_image] ✅ Đã lưu ảnh #{idx} tại: {out_path}")
        saved_paths.append(out_path)

    log(f"[ACTION=search_image] ✅ Tổng số ảnh đã lưu: {len(saved_paths)}")
    return saved_paths
