# ui/app.py
import customtkinter as ctk

from ui.login_frame import LoginFrame
from ui.dashboard_frame import DashboardFrame


class App(ctk.CTk):
    """
    Cửa sổ chính:
    - Mặc định mở LoginFrame
    - Sau khi login thành công → chuyển sang DashboardFrame
    """

    def __init__(self):
        super().__init__()

        # Cấu hình cửa sổ
        self.title("SEO WEB Tool")
        self.geometry("500x500")
        self.resizable(True, True)
        self.minsize(500, 500)

        # Frame hiện tại (login / dashboard)
        self.current_frame: ctk.CTkFrame | None = None

        # Show màn Login mặc định
        self.show_login()

    # ============================
    # CHUYỂN FRAME
    # ============================
    def show_login(self):
        if self.current_frame is not None:
            self.current_frame.destroy()
        self.current_frame = LoginFrame(self, switch_to_dashboard=self.show_dashboard)
        self.current_frame.pack(fill="both", expand=True)

    def show_dashboard(self, username: str):
        if self.current_frame is not None:
            self.current_frame.destroy()
        self.current_frame = DashboardFrame(self, username)
        self.current_frame.pack(fill="both", expand=True)
