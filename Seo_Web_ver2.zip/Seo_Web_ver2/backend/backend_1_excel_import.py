# backend/backend_1_excel_import.py
from pathlib import Path
import sqlite3
import pandas as pd
import traceback
from datetime import datetime
import json

# ==============================
# 🟦 ĐƯỜNG DẪN MẶC ĐỊNH
# ==============================
DB_PATH = Path("db/db_excel.sqlite")        # chỉ dùng nếu bạn cần default
BIGDATA_PATH = Path("db/bigdata.sqlite")
SESSION_FILE = Path("db/.bigdata_session")


# ============================================================
# 🟣 BIGDATA DATABASE – LƯU LỊCH SỬ FLOW + DASHBOARD
# ============================================================
def init_bigdata():
    """Tạo bigdata.sqlite + folder db/ nếu chưa có."""
    BIGDATA_PATH.parent.mkdir(parents=True, exist_ok=True)

    conn = sqlite3.connect(BIGDATA_PATH)
    cur = conn.cursor()

    # sessions: giữ nguyên
    cur.execute("""
        CREATE TABLE IF NOT EXISTS sessions (
            session_id INTEGER PRIMARY KEY AUTOINCREMENT,
            excel_file TEXT,
            db_output_path TEXT,
            created_at TEXT
        )
    """)

    # session_jobs
    cur.execute("""
        CREATE TABLE IF NOT EXISTS session_jobs (
            session_id INTEGER,
            job_index INTEGER,
            job_data TEXT
        )
    """)

    # session_steps
    cur.execute("""
        CREATE TABLE IF NOT EXISTS session_steps (
            session_id INTEGER,
            step INTEGER,
            step_action TEXT,
            step_name TEXT,
            step_data TEXT
        )
    """)

    conn.commit()
    conn.close()


def create_new_session(excel_file: str, db_output_path: str) -> int:
    """Tạo session mới và lưu session_id vào file."""
    init_bigdata()

    conn = sqlite3.connect(BIGDATA_PATH)
    cur = conn.cursor()

    cur.execute(
        """
        INSERT INTO sessions (excel_file, db_output_path, created_at)
        VALUES (?, ?, ?)
        """,
        (excel_file, db_output_path, datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
    )

    conn.commit()
    session_id = cur.lastrowid
    conn.close()

    SESSION_FILE.parent.mkdir(parents=True, exist_ok=True)
    SESSION_FILE.write_text(str(session_id), encoding="utf-8")

    return session_id


def get_session_id():
    if SESSION_FILE.exists():
        return int(SESSION_FILE.read_text().strip())
    return None


# ============================================================
# 🟣 GHI STEP FLOW
# ============================================================
def add_bigdata_step(step_num: int, action: str, name: str, step_data: dict):
    session_id = get_session_id()
    if session_id is None:
        return

    conn = sqlite3.connect(BIGDATA_PATH)
    cur = conn.cursor()

    cur.execute(
        """
        INSERT INTO session_steps (session_id, step, step_action, step_name, step_data)
        VALUES (?, ?, ?, ?, ?)
        """,
        (session_id, step_num, action, name, json.dumps(step_data, ensure_ascii=False)),
    )

    conn.commit()
    conn.close()


# ============================================================
# 🟣 GHI JOB DASHBOARD
# ============================================================
def add_bigdata_job(job_index: int, job_data: dict):
    session_id = get_session_id()
    if session_id is None:
        return

    conn = sqlite3.connect(BIGDATA_PATH)
    cur = conn.cursor()

    cur.execute(
        """
        INSERT INTO session_jobs (session_id, job_index, job_data)
        VALUES (?, ?, ?)
        """,
        (session_id, job_index, json.dumps(job_data, ensure_ascii=False)),
    )

    conn.commit()
    conn.close()


# ============================================================
# 🟧 ĐỌC FLOW + DASHBOARD TỪ EXCEL
# ============================================================
def load_flow_and_jobs(excel_path: str):
    excel_path = Path(excel_path)
    xls = pd.ExcelFile(excel_path)

    flow_df = None
    job_df = None

    for sheet in xls.sheet_names:
        name = sheet.strip().lower()
        if name == "flow":
            flow_df = pd.read_excel(excel_path, sheet_name=sheet)
        elif name == "dashboard":
            job_df = pd.read_excel(excel_path, sheet_name=sheet)

    return flow_df, job_df


# ============================================================
# 🟪 LƯU FLOW → session_steps
# ============================================================
def save_flow_to_bigdata(flow_df: pd.DataFrame):
    if flow_df is None or flow_df.empty:
        return

    for _, row in flow_df.iterrows():
        step_num = auto_to_int(row.get("Step"), 0)
        step_action = str(row.get("Action", ""))
        step_name = str(row.get("Name", ""))

        data_json = {}
        for col in flow_df.columns:
            if col in ("Action", "Name"):
                continue

            value = row[col]
            value = auto_to_int(value, value)

            if pd.isna(value):
                value = None

            data_json[col] = value

        add_bigdata_step(step_num, step_action, step_name, data_json)


# ============================================================
# 🟪 LƯU DASHBOARD → session_jobs
# ============================================================
def save_jobs_to_bigdata(job_df: pd.DataFrame):
    if job_df is None or job_df.empty:
        return

    for idx, row in job_df.iterrows():
        if "STT" in job_df.columns:
            job_index = int(row["STT"]) if not pd.isna(row["STT"]) else idx + 1
        else:
            job_index = idx + 1

        job_json = {col: row[col] for col in job_df.columns}
        add_bigdata_job(job_index, job_json)


# ============================================================
# 🟧 CONVERT EXCEL → SQLITE (DB cho Flow & Dashboard)
# ============================================================
def excel_to_sqlite(excel_path: str, db_path: Path) -> Path:
    excel_path = Path(excel_path)
    if not excel_path.exists():
        raise FileNotFoundError(f"Không tìm thấy Excel: {excel_path}")

    if db_path.exists():
        db_path.unlink()

    try:
        conn = sqlite3.connect(db_path)
        xls = pd.ExcelFile(excel_path)

        for sheet in xls.sheet_names:
            df = pd.read_excel(excel_path, sheet_name=sheet)

            if df.empty or len(df.columns) == 0:
                continue

            table_name = sheet.strip().replace(" ", "_")

            df = df.dropna(how="all").replace("", None).dropna(how="all")

            df.to_sql(table_name, conn, if_exists="replace", index=False)

        conn.commit()
        conn.close()
        return db_path

    except Exception as e:
        traceback.print_exc()
        raise Exception(f"Lỗi convert Excel → SQLite: {e}")


# ============================================================
# 🟧 HỖ TRỢ CHUYỂN ĐỔI DỮ LIỆU
# ============================================================
def auto_to_int(value, fallback=0):
    """
    Chuyển đổi giá trị sang int nếu có thể:
    - float 1.0 -> 1
    - '1' -> 1
    - NaN -> fallback
    - các giá trị khác giữ nguyên hoặc fallback
    """
    try:
        import pandas as pd  # đảm bảo dùng pd.isna

        if pd.isna(value):
            return fallback

        if isinstance(value, float) and value.is_integer():
            return int(value)

        if isinstance(value, int):
            return value

        if isinstance(value, str) and value.strip().isdigit():
            return int(value.strip())

        return fallback
    except Exception:
        return fallback


# ============================================================
# 🟪 MAIN ENTRY được UI gọi khi bấm START
# ============================================================
def export_excel_to_db_on_start(excel_path: str, folder_path: str) -> Path:
    """
    - Tạo DB SQLite từ Excel trong folder_path (db_excel.sqlite)
    - Tạo session BigData + lưu flow & jobs vào bigdata.sqlite
    - Trả về path DB SQLite vừa tạo (cho Backend_2, Backend_3 dùng)
    """
    folder = Path(folder_path)
    folder.mkdir(parents=True, exist_ok=True)

    db_path = folder / "db_excel.sqlite"

    # Tạo session mới
    create_new_session(excel_file=excel_path, db_output_path=str(db_path))

    # Đọc Flow + Dashboard từ Excel
    flow_df, job_df = load_flow_and_jobs(excel_path)

    # Lưu vào BigData
    save_flow_to_bigdata(flow_df)
    save_jobs_to_bigdata(job_df)

    # Tạo DB SQLite từ Excel
    return excel_to_sqlite(excel_path, db_path)
