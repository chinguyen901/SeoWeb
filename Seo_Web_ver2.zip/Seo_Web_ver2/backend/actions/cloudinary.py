# actions/cloudinary.py

import json
from pathlib import Path
from typing import Any, Dict, Optional, Callable, List

try:
    import cloudinary
    from cloudinary import uploader, config
except ImportError:
    cloudinary = None  # type: ignore


def _noop_log(msg: str) -> None:
    """Default log callback (no-op)."""
    pass


# ======================================================
# HELPERS
# ======================================================

def _normalize_config(config_raw: Any) -> Dict[str, Any]:
    """
    Chuẩn hoá var4 (config_json_api) về dict:

    Cho phép:
      - dict: dùng luôn
      - str  : cố parse JSON
      - None / lỗi: trả dict rỗng
    """
    if isinstance(config_raw, dict):
        return dict(config_raw)

    if isinstance(config_raw, str):
        s = config_raw.strip()
        if not s:
            return {}
        try:
            obj = json.loads(s)
            if isinstance(obj, dict):
                return obj
        except Exception:
            return {}

    return {}


def _ensure_path(p: str) -> Path:
    return Path(p).expanduser()


def _list_image_files(folder: Path) -> List[Path]:
    exts = {".jpg", ".jpeg", ".png", ".webp"}
    files: List[Path] = []
    for f in folder.iterdir():
        if f.is_file() and f.suffix.lower() in exts:
            files.append(f)
    return files


def _resolve_input_files(path_local: str) -> List[Path]:
    """
    var1 có thể là:
      - file ảnh
      - folder ảnh
    """
    p = _ensure_path(path_local)
    if p.is_file():
        return [p]
    if p.is_dir():
        return _list_image_files(p)
    return []


def _normalize_cloud_folder(path_folder: Any) -> str:
    """
    Cloudinary folder: dùng '/'.
    Cho phép user nhập:
      - "a/b"
      - "/a/b/"
    → normalize thành "a/b"
    """
    s = "" if path_folder is None else str(path_folder).strip()
    s = s.strip().strip("/").replace("\\", "/")
    return s


# ======================================================
# ACTION CHÍNH
# ======================================================

def cloudinary_upload(
    var0: Any,  # const 0/1 (chưa dùng – future multi behavior)
    var1: Any,  # path_local
    var2: Any,  # path_folder (cloudinary)
    var3: Any,  # blank
    var4: Any,  # config_json_api
    log_callback: Optional[Callable[[str], None]] = None,
) -> List[str]:
    """
    ACTION: cloudinary

        output = cloudinary(var0, var1, var2, var3, var4)

    - var0: const 0 hoặc 1
    - var1: path_local (file hoặc folder) cần upload lên Cloudinary
    - var2: path_folder (cloud folder)
    - var3: blank (yêu cầu để trống)
    - var4: config_json_api:
        {
          "cloud_name": "...",
          "api_key": "...",
          "api_secret": "..."
        }

    Trả về:
      - List[str]: danh sách secure_url của ảnh đã upload (có thể rỗng nếu lỗi)
    """
    log = log_callback or _noop_log

    if cloudinary is None:
        log("[ACTION=cloudinary] ❌ Thiếu thư viện cloudinary. Cài: pip install cloudinary")
        return []

    # var3 phải trống
    if var3 not in (None, "", " ", []):
        log("[ACTION=cloudinary] ⚠ Var3 được yêu cầu để trống nhưng đang có giá trị. Tool sẽ bỏ qua Var3.")

    path_local = "" if var1 is None else str(var1).strip()
    if not path_local:
        log("[ACTION=cloudinary] ❌ var1 (path_local) rỗng.")
        return []

    cloud_folder = _normalize_cloud_folder(var2)

    cfg = _normalize_config(var4)
    cloud_name = (cfg.get("cloud_name") or "").strip()
    api_key = (cfg.get("api_key") or "").strip()
    api_secret = (cfg.get("api_secret") or "").strip()

    if not cloud_name or not api_key or not api_secret:
        log("[ACTION=cloudinary] ❌ Thiếu cloud_name/api_key/api_secret trong var4.")
        return []

    # Configure Cloudinary SDK
    config(
        cloud_name=cloud_name,
        api_key=api_key,
        api_secret=api_secret,
        secure=True,
    )

    # Resolve files
    files = _resolve_input_files(path_local)
    if not files:
        log("[ACTION=cloudinary] ❌ Không tìm thấy file ảnh hợp lệ từ path_local.")
        return []

    log(f"[ACTION=cloudinary] Bắt đầu upload {len(files)} ảnh lên Cloudinary folder='{cloud_folder or '(root)'}'")

    uploaded_urls: List[str] = []

    for idx, f in enumerate(files, start=1):
        try:
            log(f"[ACTION=cloudinary] ({idx}/{len(files)}) Upload: {f}")
            # public_id: giữ tên file (không gồm extension)
            public_id = f.stem

            upload_opts: Dict[str, Any] = {
                "resource_type": "image",
                "use_filename": True,
                "unique_filename": False,  # giữ tên để dễ quản lý
                "overwrite": True,         # ghi đè nếu trùng
            }

            if cloud_folder:
                upload_opts["folder"] = cloud_folder

            # Nếu muốn giữ đúng public_id theo tên file:
            upload_opts["public_id"] = public_id
            print("1111")
            resp = uploader.upload(str(f), **upload_opts)

            # URL an toàn
            url = resp.get("secure_url") or resp.get("url") or ""
            if url:
                uploaded_urls.append(str(url))
                log(f"[ACTION=cloudinary] ✅ Uploaded: {url}")
            else:
                log("[ACTION=cloudinary] ⚠ Upload thành công nhưng không lấy được URL.")

        except Exception as e:
            log(f"[ACTION=cloudinary] ❌ Lỗi upload {f}: {e}")

    log(f"[ACTION=cloudinary] ✅ Tổng số ảnh upload thành công: {len(uploaded_urls)}")
    return uploaded_urls


# --------------------------------------------------------
# Alias đúng tên action trong docs của bạn: cloudinary
# --------------------------------------------------------
def cloudinary(
    var0: Any,
    var1: Any,
    var2: Any,
    var3: Any,
    var4: Any,
    log_callback: Optional[Callable[[str], None]] = None,
) -> List[str]:
    return cloudinary_upload(var0, var1, var2, var3, var4, log_callback=log_callback)
