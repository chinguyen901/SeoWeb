# actions/prompt_text.py

import json
from typing import Any, Dict, Optional, Callable, List

import requests


def _noop_log(msg: str) -> None:
    """Default log callback (no-op)."""
    pass


# ======================================================
# HELPERS
# ======================================================

def _normalize_config(config_raw: Any) -> Dict[str, Any]:
    """
    Chuẩn hoá var4 (config_json_api) về dict:

    Cho phép:
      - dict: dùng luôn
      - str  : cố parse JSON
      - None / lỗi: trả dict rỗng
    """
    if isinstance(config_raw, dict):
        return dict(config_raw)

    if isinstance(config_raw, str):
        s = config_raw.strip()
        if not s:
            return {}
        try:
            obj = json.loads(s)
            if isinstance(obj, dict):
                return obj
        except Exception:
            return {}

    return {}


def _build_messages(
    main_message: Any,
    context_message: Any,
    role_ai: Any,
) -> List[Dict[str, str]]:
    """
    Chuẩn hoá messages theo format giống Chat API,
    nhưng TÙY BIẾN THEO CÁCH BẠN ĐANG MUỐN DÙNG:

    Mapping:
      - var3 (role_ai)        → system message (vai trò AI), VD: "Bạn là chuyên gia khoa học"
      - var1 (main_message)   → user message phần 1
      - var2 (context_message)→ user message phần 2 (bổ sung / chi tiết)

    Kết quả sẽ là:

      [
        {"role": "system", "content": var3},
        {"role": "user",   "content": "<var1>\\n\\n<var2>"}
      ]

    Nếu thiếu cái nào thì bỏ cái đó.
    """

    # Var3: system prompt
    system_text = "" if role_ai is None else str(role_ai).strip()

    # Var1 + Var2: gộp lại thành 1 user message
    user_1 = "" if main_message is None else str(main_message).strip()
    user_2 = "" if context_message is None else str(context_message).strip()

    user_parts = [p for p in (user_1, user_2) if p]
    user_text = "\n\n".join(user_parts)

    messages: List[Dict[str, str]] = []

    if system_text:
        messages.append({"role": "system", "content": system_text})

    if user_text:
        messages.append({"role": "user", "content": user_text})

    return messages


def _extract_ai_text(resp_json: Any) -> str:
    """
    Cố gắng lấy text trả về từ nhiều dạng response khác nhau:

    - OpenAI style:
        {"choices":[{"message":{"content":"..."}}]}
        {"choices":[{"text":"..."}]}

    - Generic:
        {"output": "..."}
        {"result": "..."}
        {"data": "..."}
    """
    if not isinstance(resp_json, dict):
        try:
            return str(resp_json)
        except Exception:
            return ""

    # OpenAI / tương tự
    choices = resp_json.get("choices")
    if isinstance(choices, list) and choices:
        first = choices[0]
        if isinstance(first, dict):
            msg = first.get("message")
            if isinstance(msg, dict) and "content" in msg:
                return str(msg["content"])
            if "text" in first:
                return str(first["text"])

    # Một số dạng phổ biến khác
    for key in ("output", "result", "data", "message", "content"):
        if key in resp_json:
            try:
                return str(resp_json[key])
            except Exception:
                continue

    # fallback: stringify cả JSON
    try:
        return json.dumps(resp_json, ensure_ascii=False)
    except Exception:
        return str(resp_json)


# ======================================================
# ACTION CHÍNH
# ======================================================

def prompt_text(
    var0: Any,  # const 0/1 (chưa dùng, dành cho future: debug, đặt tên file,...)
    var1: Any,  # main_message
    var2: Any,  # context_message
    var3: Any,  # role_ai
    var4: Any,  # config_json_api
    log_callback: Optional[Callable[[str], None]] = None,
) -> str:
    """
    ACTION: prompt_text

    Tham số:
      - var0: const 0 hoặc 1 (hiện chưa dùng trong logic)
      - var1: main_message trong cú pháp tương tác với API AI
      - var2: context_message (system / hướng dẫn)
      - var3: role_ai (role chính cho main_message, ví dụ 'user', 'assistant', 'developer'...)
      - var4: config_json_api, dạng:
            {
              "api_key": "your_api_key_here",
              "endpoint": "https://api.your-ai-provider.com/v1/generate",
              "model": "model_name_here",
              ... // field khác nếu provider yêu cầu
            }

    Trả về:
      - Chuỗi text kết quả sinh từ AI (nếu thành công)
      - Hoặc chuỗi rỗng "" khi lỗi (log chi tiết qua log_callback).
    """
    log = log_callback or _noop_log

    config = _normalize_config(var4)
    api_key = config.get("api_key", "") or ""
    endpoint = (config.get("endpoint") or "").strip()
    model = (config.get("model") or "").strip()

    if not endpoint:
        log("[ACTION=prompt_text] ❌ Thiếu endpoint trong config_json_api (var4.endpoint).")
        return ""

    if not model:
        log("[ACTION=prompt_text] ⚠ model chưa được chỉ định trong config_json_api (var4.model).")

    # Chuẩn bị messages
    messages = _build_messages(
        main_message=var1,
        context_message=var2,
        role_ai=var3,
    )

    # Payload chung kiểu Chat API
    payload: Dict[str, Any] = {
        "model": model,
        "messages": messages,
    }

    # Cho phép user cấu hình thêm field custom khác trong var4.extra_payload
    extra_payload = config.get("extra_payload")
    if isinstance(extra_payload, dict):
        payload.update(extra_payload)

    # Headers
    headers = {
        "Content-Type": "application/json",
    }
    if api_key:
        # Chuẩn common: Bearer token
        headers["Authorization"] = f"Bearer {api_key}"

    log(f"[ACTION=prompt_text] Gửi request tới AI endpoint={endpoint} | model={model} | messages={len(messages)}")

    try:
        resp = requests.post(
            endpoint,
            headers=headers,
            json=payload,
            timeout=int(config.get("timeout", 60)),
        )
    except Exception as e:
        log(f"[ACTION=prompt_text] ❌ HTTP error: {e}")
        return ""

    status = resp.status_code
    text_body = resp.text

    log(f"[ACTION=prompt_text] HTTP status={status}")

    if status < 200 or status >= 300:
        # log body (rút gọn cho an toàn)
        snippet = text_body[:500] if text_body else ""
        log(f"[ACTION=prompt_text] ❌ Request thất bại, body: {snippet}")
        return ""

    # Parse JSON nếu có
    try:
        resp_json = resp.json()
        ai_text = _extract_ai_text(resp_json)
    except Exception:
        # không parse được JSON -> trả raw text
        log("[ACTION=prompt_text] ⚠ Response không phải JSON chuẩn, dùng raw text.")
        ai_text = text_body

    ai_text = ai_text or ""
    log(f"[ACTION=prompt_text] ✅ Nhận kết quả dài {len(ai_text)} ký tự.")

    return ai_text
