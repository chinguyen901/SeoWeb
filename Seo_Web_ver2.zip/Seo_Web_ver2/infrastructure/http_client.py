# infrastructure/http_client.py
"""
HTTP client dùng chung cho toàn bộ Tool.

- Không giữ API key bên trong.
- Mọi API key / endpoint / model... được truyền từ Excel (config_json_api).
"""

from typing import Any, Dict, Optional

import requests


class HTTPError(Exception):
    """Custom exception cho lỗi HTTP rõ ràng hơn."""
    pass


def request_json(
    method: str,
    url: str,
    *,
    params: Optional[Dict[str, Any]] = None,
    headers: Optional[Dict[str, str]] = None,
    json_body: Optional[Dict[str, Any]] = None,
    timeout: int = 30,
) -> Dict[str, Any]:
    """
    Gửi request HTTP và parse JSON trả về.
    - method: "GET" | "POST" | ...
    - url: endpoint
    - params: query string
    - headers: headers
    - json_body: body JSON (cho POST/PUT)
    """
    method = method.upper()

    try:
        resp = requests.request(
            method=method,
            url=url,
            params=params,
            headers=headers,
            json=json_body,
            timeout=timeout,
        )
    except Exception as e:
        raise HTTPError(f"Lỗi kết nối HTTP tới {url}: {e}") from e

    if not (200 <= resp.status_code < 300):
        # Cố gắng đọc JSON lỗi, fallback text
        try:
            err_json = resp.json()
        except Exception:
            err_json = resp.text
        raise HTTPError(
            f"HTTP {resp.status_code} khi gọi {url} – body: {err_json}"
        )

    try:
        return resp.json()
    except Exception as e:
        raise HTTPError(f"Lỗi parse JSON từ {url}: {e}") from e


def call_ai_from_config(
    config: Dict[str, Any],
    payload: Dict[str, Any],
    timeout: int = 60,
) -> Dict[str, Any]:
    """
    Helper cho các action kiểu prompt_text / prompt_image:
    - config được đọc từ Var4 (config_json_api) trong Excel, ví dụ:

      {
        "api_key": "...",
        "endpoint": "https://api.xxx.com/v1/generate",
        "model": "gpt-4o-mini"
      }

    - payload: body JSON gửi lên API (messages, prompt, ...)
    """
    endpoint = config.get("endpoint")
    api_key = config.get("api_key")

    if not endpoint:
        raise HTTPError("Thiếu 'endpoint' trong config_json_api")
    if not api_key:
        # tuỳ bạn: có thể hỗ trợ API không cần key
        raise HTTPError("Thiếu 'api_key' trong config_json_api")

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }

    return request_json(
        method="POST",
        url=endpoint,
        headers=headers,
        json_body=payload,
        timeout=timeout,
    )
