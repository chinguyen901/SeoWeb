# backend/backend_3_worker_pool.py
# =========================================
# BACKEND 3 – MULTITHREAD JOB EXECUTOR (POOL)
# =========================================

from concurrent.futures import ThreadPoolExecutor
from typing import List, Dict, Any, Callable, Tuple

from backend.flow_engine.step_executor import run_single_job


def start_jobs_multithread(
    jobs: List[Dict[str, Any]],
    flow_steps: List[Dict[str, Any]],
    max_threads: int,
    db_path: str,
    log_callback: Callable[[str], None],
    stop_event,
) -> Tuple[List[Any], Any]:
    """
    - Tạo ThreadPoolExecutor với số worker thực tế = min(max_threads, 5)
      (dù UI nhập 20, 100... thì cũng chỉ chạy tối đa 5 job song song)
    - Submit từng job vào pool, gọi run_single_job()
    - Trả về (futures, stop_event)
    """

    # Giới hạn số worker thực tế
    effective_threads = max(1, min(max_threads, 5))
    if max_threads > effective_threads:
        log_callback(
            f"⚠ Yêu cầu {max_threads} thread, nhưng chỉ cho phép tối đa {effective_threads} worker song song."
        )

    executor = ThreadPoolExecutor(max_workers=effective_threads)
    futures = []

    for job in jobs:
        future = executor.submit(
            run_single_job,
            job,
            flow_steps,
            db_path,
            log_callback,
            stop_event,
        )
        futures.append(future)

    log_callback(
        f"🚀 Đã tạo {len(futures)} future cho {len(jobs)} job "
        f"(tối đa {effective_threads} worker chạy song song)."
    )

    return futures, stop_event
