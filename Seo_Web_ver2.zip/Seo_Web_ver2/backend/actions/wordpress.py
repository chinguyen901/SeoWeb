# actions/wordpress.py

import json
import mimetypes
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional, Callable, List, Tuple

import requests

try:
    from zoneinfo import ZoneInfo  # py>=3.9
except Exception:
    ZoneInfo = None


def _noop_log(msg: str) -> None:
    pass


# ======================================================
# HELPERS
# ======================================================

def _get_post_id_by_slug(
    session: requests.Session,
    base_v2: str,
    auth: Tuple[str, str],
    slug: str,
    log: Callable[[str], None],
) -> Optional[int]:
    slug = (slug or "").strip()
    if not slug:
        return None

    try:
        r = session.get(
            f"{base_v2}/posts",
            params={"slug": slug, "per_page": 1},
            auth=auth,
            timeout=60,
        )
        if 200 <= r.status_code < 300:
            data = r.json()
            if isinstance(data, list) and data:
                pid = data[0].get("id")
                return int(pid) if pid else None
        else:
            log(f"[ACTION=wordpress] ⚠ GET post by slug failed: HTTP {r.status_code} | {_safe(r.text)}")
    except Exception as e:
        log(f"[ACTION=wordpress] ⚠ Exception when GET post by slug: {e}")

    return None

def _normalize_dict(raw: Any) -> Dict[str, Any]:
    if isinstance(raw, dict):
        return dict(raw)
    if isinstance(raw, str):
        s = raw.strip()
        if not s:
            return {}
        try:
            obj = json.loads(s)
            return obj if isinstance(obj, dict) else {}
        except Exception:
            return {}
    return {}


def _wp_base(url: str) -> str:
    return url.rstrip("/") + "/wp-json/wp/v2"


def _safe(s: str, n: int = 120) -> str:
    s = s or ""
    return s[:n] + ("..." if len(s) > n else "")


def _auth_tuple(user: str, apppass: str) -> Tuple[str, str]:
    # WordPress Application Password dùng Basic Auth
    return (user, apppass)


def _parse_dt(dt_str: str, tz_name: str) -> Optional[datetime]:
    if not dt_str:
        return None
    try:
        dt = datetime.fromisoformat(dt_str)
    except Exception:
        return None

    if dt.tzinfo is not None:
        return dt

    if ZoneInfo is None:
        # fallback: coi như naive local time (WP sẽ hiểu theo timezone site)
        return dt

    try:
        return dt.replace(tzinfo=ZoneInfo(tz_name))
    except Exception:
        return dt


def _pick_exact_term(items: List[dict], name: str) -> Optional[int]:
    want = (name or "").strip().lower()
    for it in items:
        if isinstance(it, dict) and (it.get("name") or "").strip().lower() == want:
            return it.get("id")
    return None


def _get_or_create_term(
    session: requests.Session,
    base_v2: str,
    auth: Tuple[str, str],
    term_type: str,   # "categories" | "tags"
    name: str,
    log: Callable[[str], None],
) -> Optional[int]:
    name = (name or "").strip()
    if not name:
        return None

    # 1) search
    try:
        r = session.get(
            f"{base_v2}/{term_type}",
            params={"search": name, "per_page": 100},
            auth=auth,
            timeout=60,
        )
        if 200 <= r.status_code < 300:
            items = r.json() if isinstance(r.json(), list) else []
            exact_id = _pick_exact_term(items, name)
            if exact_id:
                return int(exact_id)
    except Exception:
        pass

    # 2) create
    try:
        r = session.post(
            f"{base_v2}/{term_type}",
            json={"name": name},
            auth=auth,
            timeout=60,
        )
        if 200 <= r.status_code < 300:
            obj = r.json() if isinstance(r.json(), dict) else {}
            tid = obj.get("id")
            return int(tid) if tid else None
        else:
            log(f"[ACTION=wordpress] ⚠ Không tạo được {term_type}='{name}': HTTP {r.status_code} | {_safe(r.text)}")
            return None
    except Exception as e:
        log(f"[ACTION=wordpress] ⚠ Lỗi tạo {term_type}='{name}': {e}")
        return None


def _upload_featured_image(
    session: requests.Session,
    base_v2: str,
    auth: Tuple[str, str],
    image_path: str,
    log: Callable[[str], None],
) -> Optional[int]:
    p = Path(image_path).expanduser()
    if not p.is_file():
        log(f"[ACTION=wordpress] ⚠ featured_image_local không tồn tại: {p}")
        return None

    mime, _ = mimetypes.guess_type(str(p))
    if not mime:
        mime = "application/octet-stream"

    headers = {
        "Content-Disposition": f'attachment; filename="{p.name}"',
        "Content-Type": mime,
    }

    try:
        with p.open("rb") as f:
            r = session.post(
                f"{base_v2}/media",
                headers=headers,
                data=f.read(),
                auth=auth,
                timeout=120,
            )
        if 200 <= r.status_code < 300:
            obj = r.json() if isinstance(r.json(), dict) else {}
            mid = obj.get("id")
            return int(mid) if mid else None

        log(f"[ACTION=wordpress] ⚠ Upload media lỗi: HTTP {r.status_code} | {_safe(r.text)}")
        return None
    except Exception as e:
        log(f"[ACTION=wordpress] ⚠ Upload media exception: {e}")
        return None


def _rankmath_meta_from_cfg(cfg: Dict[str, Any]) -> Dict[str, Any]:
    """
    RankMath thường lưu meta theo key dạng rank_math_*
    (Tuỳ site cấu hình, có thể cần bật REST meta.)
    """
    title = (cfg.get("title") or "").strip()
    desc = (cfg.get("description") or "").strip()
    focus = (cfg.get("focus_keyword") or "").strip()
    secondary = cfg.get("secondary_keywords") or []

    if isinstance(secondary, list):
        secondary_list = [str(x).strip() for x in secondary if str(x).strip()]
    else:
        secondary_list = []

    meta: Dict[str, Any] = {}
    if title:
        meta["rank_math_title"] = title
    if desc:
        meta["rank_math_description"] = desc
    if focus:
        meta["rank_math_focus_keyword"] = focus
    if secondary_list:
        meta["rank_math_secondary_keywords"] = ", ".join(secondary_list)

    return meta


# ======================================================
# ACTION CHÍNH
# ======================================================

def wordpress(
    var0: Any,  # const 0/1 (chưa dùng)
    var1: Any,  # html_body
    var2: Any,  # config_json_article
    var3: Any,  # config_json_seo_rankmath
    var4: Any,  # config_json_api
    log_callback: Optional[Callable[[str], None]] = None,
) -> Dict[str, Any]:
    """
    ACTION: wordpress
      output = wordpress(var0, var1, var2, var3, var4)

    - var1: html_body
    - var2: config_json_article (title/excerpt/slug/status/categories(tags by NAME)/featured_image_local/schedule...)
    - var3: config_json_seo_rankmath (RankMath meta)
    - var4: config_json_api {url,user,apppass}
    """
    print("1111")
    log = log_callback or _noop_log

    html_body = "" if var1 is None else str(var1)
    if not html_body.strip():
        log("[ACTION=wordpress] ❌ html_body (var1) rỗng.")
        return {"success": False, "error": "empty_html_body"}

    article = _normalize_dict(var2)
    seo = _normalize_dict(var3)
    api = _normalize_dict(var4)

    wp_url = (api.get("url") or "").strip()
    user = (api.get("user") or "").strip()
    apppass = (api.get("apppass") or "").strip()

    if not wp_url or not user or not apppass:
        log("[ACTION=wordpress] ❌ Thiếu url/user/apppass trong var4.")
        return {"success": False, "error": "missing_api_config"}

    base_v2 = _wp_base(wp_url)
    auth = _auth_tuple(user, apppass)
    session = requests.Session()

    # --- schedule logic ---
    status = (article.get("status") or "draft").strip().lower()
    schedule = article.get("schedule") or {}
    if not isinstance(schedule, dict):
        schedule = {}

    if bool(schedule.get("enable")):
        status = "future"
        tz = (schedule.get("timezone") or "Asia/Ho_Chi_Minh").strip()
        dt = _parse_dt(str(schedule.get("datetime") or ""), tz)
    else:
        dt = None

    # --- categories/tags by NAME ---
    cat_names = article.get("categories") or []
    tag_names = article.get("tags") or []

    if not isinstance(cat_names, list):
        cat_names = []
    if not isinstance(tag_names, list):
        tag_names = []

    cat_ids: List[int] = []
    for name in cat_names:
        tid = _get_or_create_term(session, base_v2, auth, "categories", str(name), log)
        if tid:
            cat_ids.append(int(tid))

    tag_ids: List[int] = []
    for name in tag_names:
        tid = _get_or_create_term(session, base_v2, auth, "tags", str(name), log)
        if tid:
            tag_ids.append(int(tid))

    # --- upload featured image ---
    featured_media_id: Optional[int] = None
    featured_local = (article.get("featured_image_local") or "").strip()
    if featured_local:
        featured_media_id = _upload_featured_image(session, base_v2, auth, featured_local, log)

    # --- build post payload ---
    payload: Dict[str, Any] = {
        "title": (article.get("title") or "").strip(),
        "content": html_body,
        "excerpt": (article.get("excerpt") or "").strip(),
        "slug": (article.get("slug") or "").strip(),
        "status": status,
    }

    if cat_ids:
        payload["categories"] = cat_ids
    if tag_ids:
        payload["tags"] = tag_ids
    if featured_media_id:
        payload["featured_media"] = featured_media_id

    if dt is not None:
        # WP nhận ISO format. Nếu dt có tzinfo -> chuyển về ISO string.
        payload["date"] = dt.isoformat()

    # --- RankMath meta ---
    meta = _rankmath_meta_from_cfg(seo)
    if meta:
        payload["meta"] = meta

    log(f"[ACTION=wordpress] Tạo bài viết: title='{_safe(payload.get('title',''))}' status={status}")
    # # --- overwrite logic (update by slug) ---
    # overwrite = bool(article.get("overwrite"))
    # slug_for_overwrite = (article.get("slug") or "").strip()

    # method = "POST"
    # url = f"{base_v2}/posts"

    # if overwrite and slug_for_overwrite:
    #     post_id_existing = _get_post_id_by_slug(session, base_v2, auth, slug_for_overwrite, log)
    #     if post_id_existing:
    #         method = "PUT"
    #         url = f"{base_v2}/posts/{post_id_existing}"
    #         log(f"[ACTION=wordpress] overwrite=true → UPDATE post_id={post_id_existing} slug='{slug_for_overwrite}'")
    #     else:
    #         log(f"[ACTION=wordpress] overwrite=true nhưng không tìm thấy post theo slug='{slug_for_overwrite}' → CREATE mới")

    # # --- create/update post ---
    # try:
    #     if method == "PUT":
    #         r = session.post(  # nhiều host chặn PUT; WP vẫn hỗ trợ POST + _method override
    #             url,
    #             json={**payload, "_method": "PUT"},
    #             auth=auth,
    #             timeout=120,
    #         )
    #         # Nếu host cho phép PUT chuẩn, bạn có thể đổi thành:
    #         # r = session.put(url, json=payload, auth=auth, timeout=120)
    #     else:
    #         r = session.post(
    #             url,
    #             json=payload,
    #             auth=auth,
    #             timeout=120,
    #         )
    # except Exception as e:
    #     log(f"[ACTION=wordpress] ❌ HTTP error: {e}")
    #     return {"success": False, "error": str(e)}

    # --- create post ---
    try:
        r = session.post(
            f"{base_v2}/posts",
            json=payload,
            auth=auth,
            timeout=120,
        )
    except Exception as e:
        log(f"[ACTION=wordpress] ❌ HTTP error: {e}")
        return {"success": False, "error": str(e)}

    if not (200 <= r.status_code < 300):
        log(f"[ACTION=wordpress] ❌ Create post failed: HTTP {r.status_code} | {_safe(r.text, 500)}")
        return {"success": False, "status_code": r.status_code, "error": r.text}

    obj = r.json() if isinstance(r.json(), dict) else {}
    post_id = obj.get("id")
    link = obj.get("link")
    returned_status = obj.get("status")

    log(f"[ACTION=wordpress] ✅ OK post_id={post_id} status={returned_status}")

    return {
        "success": True,
        "post_id": post_id,
        "link": link,
        "status": returned_status,
        "featured_media_id": featured_media_id,
        "category_ids": cat_ids,
        "tag_ids": tag_ids,
        "meta_sent": meta,
        "raw": obj,
    }
